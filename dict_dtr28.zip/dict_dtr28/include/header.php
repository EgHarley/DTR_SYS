<?php
// Start PHP section (if needed for future dynamic content)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Time Record and Travel Order System</title>
    <link rel="icon" type="image/x-icon" href="images/LOGO.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .header-container {
            display: flex;
            flex-direction: column;
            width: 100%;
        }

        .header-section {
            width: 100%;
        }

        .blue-section {
            background-color: #10346C; /* Blue */
            height: 1.7vw;
            min-height: 15px; /* Added minimum height for small screens */
        }

        .white-section {
            background-color: #FFFFFF; /* White */
            height: 0.2vw;
            min-height: 1px; /* Added minimum height for small screens */
        }

        .red-section {
            background-color: #E60000; /* Red */
            height: 1.7vw;
            min-height: 15px;
        }

        .yellow-section {
            background-color: #E3CA22; /* Yellow */
            height: 1.7vw;
            min-height: 15px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3) !important;
        }

        .custom-navbar .navbar-toggler-icon {
            filter: invert(1);
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            /* Adjust header for mobile */
            .header-container {
                position: sticky;
                top: 0;
                z-index: 100;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header-container">
    <div class="header-section blue-section"></div>
    <div class="header-section white-section"></div> 
    <div class="header-section red-section"></div>
    <div class="header-section white-section"></div>
    <div class="header-section yellow-section"></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>