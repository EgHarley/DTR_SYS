<?php
include('../connection.php');

if (!empty($_POST["username"])) {
    $username = trim($_POST["username"]); // Trim spaces
    $username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); // XSS prevention
    $ulvl = "Employee";

    if ($stmt = $conn->prepare("SELECT status FROM tbl_user WHERE username = ? && ulvl = ? LIMIT 1")) {
        $stmt->bind_param("ss", $username, $ulvl);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        $stmt->close();

        if ($status === "Approved") {
            echo "<span id='username-validation' style='color:green'>Username is valid.</span>";
            echo "<script>$('#save').prop('disabled', false);</script>";
        } else {
            echo "<span id='username-validation' style='color:red'>Invalid Username.</span>";
            echo "<script>$('#save').prop('disabled', true);</script>";
        }
    } else {
        echo "<span style='color:red'>Database error.</span>";
    }
}
?>