<?php
session_start();
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// include 'include/header.php'

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Employee Attendance</title>
  <link rel="icon" type="image/x-icon" href="images/LOGO.ico">
  <link rel="stylesheet" href="sidebar/style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <!-- sweet alert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
  body {
    font-family: Arial, sans-serif;
  }

  ul.nav-list {
    padding-left: 0rem;
  }

  .dropdown-links {
    display: none;
    /* Hide the links by default */
    list-style-type: none;
    padding-left: 20px;
  }

  /* Show dropdown on hover */
  .dropdown:hover .dropdown-links {
    display: block;
  }

  .dropdown-links li {
    margin: 5px 0;
  }

  .dropdown-links a {
    text-decoration: none;
    color: white;
  }

  .dropdown-links a:hover {
    color: #007bff;
    /* Change color on hover */
  }

  .icon {
    display: block;
    margin: 75px auto 0;
    width: 200px;
    height: auto;
  }

  #btn {
    height: 90px;
    /* Adjust height */
    /* line-height: 100px;  */
  }

  .user-info-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    margin-top: 10px;
  }

  .user-info {
    display: flex;
    align-items: center;
    color: #000;
  }

  .current-date {
    color: #000;
    font-size: 16px;
  }

  .card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    margin-top: -55px;
  }

  .time-display {
    font-size: 72px;
    font-weight: bold;
    margin: 5px 0;
    /* font-family: Digital-7 mono; */
  }

  .time-buttons button {
    padding: 15px 30px;
    margin: 10px;
    font-size: 18px;
    border-radius: 8px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
  }

  .time-buttons button:disabled {
    background-color: #6c757d !important;
    /* Gray color */
    border-color: #6c757d !important;
    cursor: not-allowed;
    opacity: 0.65;
    /* Slight transparency */
  }

  table {
    width: 100%;
    margin-top: 40px;
    border-collapse: collapse;
  }

  table th,
  table td {
    padding: 15px;
    border: 1px solid #dee2e6;
    text-align: center;
  }

  table th {
    background-color: #f1f1f1;
    font-size: 18px;
  }

  table td {
    font-size: 16px;
  }

  /* history button */
  .history-btn {
    background-color: #10346C !important;
    border-color: #10346C !important;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
  }

  .history-btn:hover {
    background-color: #0c2957 !important;
    border-color: #0c2957 !important;
  }

  .custom-confirm-button {
    background-color: #10346C !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }

  .custom-cancel-button {
    background-color: #E60000 !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }
  .logoutLink {
    color: #10346C;
  }
  
  
</style>

<body>
  <div class="sidebar">
    <div class="logo_details">
      <i class="fa-solid fa-circle-user" id="btn" style="color: #10346C; "></i>
    <span class="icon">
          <?php
          //echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
          echo  htmlspecialchars($_SESSION['fullname']);
          ?>
        </span>
    </div><br><br>


    <ul class="nav-list">
      <li>
        <a href="dashboard.php">
          <i class="fa-solid fa-calendar-check"></i>
          <span class="link_name">Attendance</span>
        </a>
      </li>
      <li>
        <a href="travelorder/travelorder.php">
          <i class="fa-solid fa-plane-departure"></i>
          <span class="link_name">Travel Orders</span>
        </a>
      </li><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      
      <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
    </ul>
      <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; ">
          <span style="color: #10346C";>Logout</span>
        </a>
  </div>

  <section class="home-section">

    <?php include 'include/header.php'; ?>

    <div class="user-info-container">
      <div class="user-info">
      <img src="images/bagong_pinas.png" alt="User Image" style="width: 100%; max-width: 50px; height: auto; display: block; margin-left: 20px; margin-bottom: 1px; margin-top: -10px;">
      <img src="images/dict_logo.png" alt="User Image" style="width: 100%; max-width: 100px; height: auto; display: block; margin-left: 20px;margin-top: -10px;">
      </div>

      <div class="current-date d-flex align-items-center">
        <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
        <span id="current-date"></span>
      </div>
    </div>

    <br><br>

    <!-- main dash contents -->
    <main class="px-3 py-2" style="background-color: #e6e4e4;">
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
              <i class="fa-solid fa-calendar-check me-2 fs-4"></i>
              <span class="fw-bold fs-4">Attendance</span>
            </div>
            <a href="history.php" class="btn btn-primary history-btn" style="flex-shrink: 0;">History</a>
          </div>

          <div class="card-body row mb-3">
            <!-- kargahan mo dito kupal -->

            <!-- Centered Attendance Card -->
            <div class="d-flex justify-content-center mt-4">
              <div class="card text-center" style="max-width: 500px; width: 100%; margin-top: 1px;">
                <!-- <h4 class="mt-3"><i class="fas fa-calendar-check"></i> Attendance</h4> -->
                <div>
                  <strong id="current-date"></strong>
                </div>
                <div class="time-display" id="current-time">00:00:00 </div>
                <div class="text-muted">You are now within the vicinity of the office!</div>
                <div class="time-buttons mt-3">
                  <button id="time-in-btn" class="btn btn-success"
                    style="background-color: #10346C; color: white; width: 180px; height: 60px; font-size: 18px;"
                    onclick="timeIn()">Time In</button>
                  <button id="time-out-btn" class="btn btn-secondary"
                    style="background-color: #E60000; color: white; width: 180px; height: 60px; font-size: 18px;"
                    onclick="timeOut()" disabled>Time Out</button>
                </div><br>
                <table class="table mt-3" style="pointer-events: none;">
                  <thead>
                  <tr>
                    <th style="background-color: #DEDEDE;">Record</th>
                    <th style="background-color: #DEDEDE;">Time</th>
                    <th style="background-color: #DEDEDE;">Undertime (min)</th>
                  </tr>
                  </thead>
                    <tbody id="attendance-record" style="pointer-events: none;">
                      
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </div>
      </div>
    </main>


  </section>

  <!-- Scripts -->
  <script src="sidebar/sidebar.js"></script>

  <script>
    function updateClock() {
      const now = new Date();
      const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
      document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
    }

    setInterval(updateClock, 1000);

    // Call it immediately to display the time without delay
    updateClock();

    // Time slots for validation
    const morningStart = new Date();
    morningStart.setHours(8, 0, 0, 0);

    const morningEnd = new Date();
    morningEnd.setHours(12, 0, 0, 0);

    const afternoonStart = new Date();
    afternoonStart.setHours(13, 0, 0, 0);

    const afternoonEnd = new Date();
    afternoonEnd.setHours(17, 0, 0, 0);

    let morningTimeIn = false;
    let morningTimeOut = false;
    let afternoonTimeIn = false;
    let afternoonTimeOut = false;

     function calculateUndertime(currentTime, expectedTime) {
      let undertimeMinutes = 0;
      if (currentTime < expectedTime) {
          undertimeMinutes = Math.round((expectedTime - currentTime) / (1000 * 60));
      }
      return undertimeMinutes;
      }

    function timeIn() {
      const now = new Date();
      const timeInPHT = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
      const recordDate = now.toISOString().slice(0, 10);
      let undertime = 0;

      if (now >= morningStart && now <= morningEnd && !morningTimeIn) {
        undertime = calculateUndertime(now, morningStart);
        morningTimeIn = true;
      } else if (now >= afternoonStart && now <= afternoonEnd && !afternoonTimeIn) {
        undertime = calculateUndertime(now, afternoonStart);
        afternoonTimeIn = true;
      } else {
        alert('Time-in not allowed at this time.');
        return;
      }

      const xhr = new XMLHttpRequest();
      xhr.open("POST", "insert_time.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      xhr.onload = function () {
        if (xhr.status === 200) {
          alert(xhr.responseText);
          const recordRow = `
                        <tr>
                            <td>TIME IN</td>
                            <td>${timeInPHT}</td>
                            <td>${undertime}</td>
                        </tr>
                        
                    `;
            document.getElementById('attendance-record').innerHTML += recordRow;
          document.getElementById('time-in-btn').disabled = morningTimeIn && afternoonTimeIn;
        } else {
          alert("Error: " + xhr.responseText);
        }
      };

      xhr.send(`action=time_in&username=${encodeURIComponent("<?php echo $_SESSION['username']; ?>")}&time_in=${now.toISOString()}&record_date=${recordDate}&undertime=${undertime}`);
    }

    function timeOut() {
      const now = new Date();
      const timeOutPHT = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
      const recordDate = now.toISOString().slice(0, 10);
      let undertime = 0;

      if (now >= morningStart && now <= morningEnd && morningTimeIn && !morningTimeOut) {
        undertime = calculateUndertime(morningEnd, now);
        morningTimeOut = true;
      } else if (now >= afternoonStart && now <= afternoonEnd && afternoonTimeIn && !afternoonTimeOut) {
        undertime = calculateUndertime(afternoonEnd, now);
        afternoonTimeOut = true;
      } else {
        alert('Time-out not allowed at this time.');
        return;
      }

      const xhr = new XMLHttpRequest();
      xhr.open("POST", "insert_time.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      xhr.onload = function () {
        if (xhr.status === 200) {
          alert(xhr.responseText);
          const recordRow = `
                        <tr>
                            <td>TIME OUT</td>
                            <td>${timeOutPHT}</td>
                            <td>${undertime}</td>
                        </tr>
                    `;
          document.getElementById('attendance-record').innerHTML += recordRow;
          document.getElementById('time-out-btn').disabled = morningTimeOut && afternoonTimeOut;
        } else {
          alert("Error: " + xhr.responseText);
        }
      };

      xhr.send(`action=time_out&username=${encodeURIComponent("<?php echo $_SESSION['username']; ?>")}&time_out=${now.toISOString()}&record_date=${recordDate}&undertime=${undertime}`);
    }

    document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("time-in-pm-btn").addEventListener("click", timeInPM);
    document.getElementById("time-out-pm-btn").addEventListener("click", timeOutPM);
});

function timeInPm() {
    const now = new Date();
    const timeInPHT = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
    const recordDate = now.toISOString().slice(0, 10);
    let undertime = 0;

    if (now >= afternoonStart && now <= afternoonEnd && !afternoonTimeIn) {
        undertime = calculateUndertime(now, afternoonStart);
        afternoonTimeIn = true;
    } else {
        alert('Time-in PM not allowed at this time.');
        return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "insert_time.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function () {
        if (xhr.status === 200) {
            alert(xhr.responseText);
            const recordRow = `
                <tr>
                    <td>TIME IN PM</td>
                    <td>${timeInPHT}</td>
                    <td>${undertime}</td>
                </tr>
            `;
            document.getElementById('attendance-record').innerHTML += recordRow;
            document.getElementById('time-in-pm-btn').disabled = afternoonTimeIn;
        } else {
            alert("Error: " + xhr.responseText);
        }
    };

    xhr.send(`action=time_in_pm&username=${encodeURIComponent("<?php echo $_SESSION['username']; ?>")}&time_in=${now.toISOString()}&record_date=${recordDate}&undertime=${undertime}`);
}

function timeOutPm() {
    const now = new Date();
    const timeOutPHT = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
    const recordDate = now.toISOString().slice(0, 10);
    let undertime = 0;

    if (now >= afternoonStart && now <= afternoonEnd && afternoonTimeIn && !afternoonTimeOut) {
        undertime = calculateUndertime(afternoonEnd, now);
        afternoonTimeOut = true;
    } else {
        alert('Time-out PM not allowed at this time.');
        return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "insert_time.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function () {
        if (xhr.status === 200) {
            alert(xhr.responseText);
            const recordRow = `
                <tr>
                    <td>TIME OUT PM</td>
                    <td>${timeOutPHT}</td>
                    <td>${undertime}</td>
                </tr>
            `;
            document.getElementById('attendance-record').innerHTML += recordRow;
            document.getElementById('time-out-pm-btn').disabled = afternoonTimeOut;
        } else {
            alert("Error: " + xhr.responseText);
        }
    };

    xhr.send(`action=time_out_pm&username=${encodeURIComponent("<?php echo $_SESSION['username']; ?>")}&time_out=${now.toISOString()}&record_date=${recordDate}&undertime=${undertime}`);
}

// Buttons for Time In PM and Time Out PM
document.write(`
    <button id="time-in-pm-btn" style="display: none;">Time In PM</button>
    <button id="time-out-pm-btn" style="display: none;">Time Out PM</button>
`);

// Check and swap buttons based on morning time-in/time-out completion
function checkAndSwapButtons() {
    if (morningTimeIn && morningTimeOut) {
        document.getElementById('time-in-pm-btn').style.display = 'inline-block';
        document.getElementById('time-out-pm-btn').style.display = 'inline-block';
    }
}

// Call this function after morning time-in/time-out actions
document.addEventListener("DOMContentLoaded", function() {
    checkAndSwapButtons();
});



    setInterval(() => {
      const now = new Date();
      const timeOutBtn = document.getElementById('time-out-btn');
      const canTimeOut = (now <= afternoonEnd) && (!morningTimeOut || !afternoonTimeOut);
      document.getElementById('time-in-btn').disabled = (now > afternoonEnd) || (morningTimeIn && afternoonTimeIn);
      document.getElementById('time-out-btn').disabled = (now > afternoonEnd) || (morningTimeOut && afternoonTimeOut);
      timeOutBtn.disabled = !canTimeOut;
      if (canTimeOut) {
        timeOutBtn.classList.remove('btn-secondary');
        timeOutBtn.classList.add('btn-danger'); // Red color when enabled
      } else {
        timeOutBtn.classList.remove('btn-danger');
        timeOutBtn.classList.add('btn-secondary'); // Gray color when disabled
      }
    }, 1000);

    function saveStateToLocalStorage() {
      const state = {
        morningTimeIn,
        morningTimeOut,
        afternoonTimeIn,
        afternoonTimeOut,
      };
      localStorage.setItem('attendanceState', JSON.stringify(state));
    }

    function loadStateFromLocalStorage() {
      const state = JSON.parse(localStorage.getItem('attendanceState'));
      if (state) {
        morningTimeIn = state.morningTimeIn;
        morningTimeOut = state.morningTimeOut;
        afternoonTimeIn = state.afternoonTimeIn;
        afternoonTimeOut = state.afternoonTimeOut;
      }
    }
    function updateDisplayedTime() {
      fetch('latest_time.php')
        .then(response => response.json())
        .then(data => {
          if (data.time) {
            document.getElementById('current-time').textContent = new Date(data.time).toLocaleTimeString();
          }
        })
        .catch(error => console.error('Error fetching latest time:', error));
    }

    // Call this function on page load and after a time-in or time-out action
    updateDisplayedTime();

    // Example usage after button actions
    document.getElementById('time-in-btn').addEventListener('click', () => {
      // Perform Time-In logic here
      updateDisplayedTime();
    });
    document.getElementById('time-out-btn').addEventListener('click', () => {
      // Perform Time-Out logic here
      updateDisplayedTime();
    });
  </script>

  <!-- Logout Script -->
  <script>
    document.getElementById("logoutLink").addEventListener("click", function (event) {
      event.preventDefault(); // Prevent immediate navigation

      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: "custom-confirm-button btn",
          cancelButton: "custom-cancel-button btn"
        },
        buttonsStyling: false
      });

      swalWithBootstrapButtons.fire({
        title: "Are you sure you want <br> to log out?",
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        reverseButtons: false
      }).then((result) => {
        if (result.isConfirmed) {
          swalWithBootstrapButtons.fire({
            title: "Successfully logged out!",
            icon: "success",
            showConfirmButton: false, // Remove "OK" button
            timer: 2000, // Auto-close after 2 seconds
            timerProgressBar: true // Show progress bar
          });

          setTimeout(() => {
            window.location.href = "logout/logout.php"; // Redirect after 2 seconds
          }, 1090);
        }
      });
    });
  </script>

</body>

</html>