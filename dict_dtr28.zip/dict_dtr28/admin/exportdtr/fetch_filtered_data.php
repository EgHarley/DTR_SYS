<?php
require '../connection.php'; // Adjust path as needed

// Fetch default values if filters are not set
$defaultQuery = "SELECT 
                    YEAR(MAX(date_approved)) AS latest_year, 
                    MONTHNAME(MAX(date_approved)) AS latest_month, 
                    MAX(date_approved) AS latest_date 
                 FROM tbl_user";
$defaultResult = $conn->query($defaultQuery);
$defaultRow = $defaultResult->fetch_assoc();

$latestYear = $defaultRow['latest_year'] ?? '';
$latestMonth = $defaultRow['latest_month'] ?? '';
$latestDay = date('j', strtotime($defaultRow['latest_date'] ?? ''));
$latestPeriod = ($latestDay <= 15) ? '1st Half' : '2nd Half';

// Set default filters if not provided in GET request
$year = $_GET['year'] ?? $latestYear;
$month = $_GET['month'] ?? $latestMonth;
$period = $_GET['period'] ?? $latestPeriod;
$designation = $_GET['designation'] ?? 'La Union';
$division = $_GET['division'] ?? 'TOD';

$query = "SELECT fname, username, designation, division FROM tbl_user WHERE 1";

if (!empty($year)) {
    $query .= " AND YEAR(date_approved) = '$year'";
}
if (!empty($month)) {
    $query .= " AND MONTHNAME(date_approved) = '$month'";
}
if (!empty($period)) {
    if ($period == "1st Half") {
        $query .= " AND DAY(date_approved) BETWEEN 1 AND 15";
    } elseif ($period == "2nd Half") {
        $query .= " AND DAY(date_approved) BETWEEN 16 AND 31";
    }
}
if (!empty($designation)) {
    $query .= " AND designation = '$designation'";
}
if (!empty($division)) {
    $query .= " AND division = '$division'";
}

$query .= " ORDER BY date_approved DESC";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['fname']}</td>
                <td>{$row['designation']}</td>
                <td>{$row['division']}</td>
                <td>
                    <a href='view_dtr.php?username={$row['username']}''title='ViewDTR' class='btn btn-primary' 
                        style='background-color: #10346C; color: white;'>
                        <i class='fas fa-eye'></i> 
                    </a>


                    <a href='export.php?username={$row['username']}'title='Export' class='btn btn-primary' 
                        style='background-color: #10346C; color: white;'>
                        <i class='fas fa-file-export'> </i>
                    </a> 

                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4' class='text-center'>No records found</td></tr>";
}
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
