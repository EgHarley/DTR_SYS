<?php
require '../../connection.php'; // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Retrieve user details from tbl_user
    $query = "SELECT * FROM tbl_user WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Insert user details into tbl_archived_user INCLUDING ulvl
        $insertQuery = "INSERT INTO tbl_archived_user (username, password, fname, division, designation, position, ulvl, remaining_days)
                        VALUES ('{$user['username']}', '{$user['password']}', '{$user['fname']}', '{$user['division']}',
                                '{$user['designation']}', '{$user['position']}', '{$user['ulvl']}', '{$user['remaining_days']}')";

        if (mysqli_query($conn, $insertQuery)) {
            // Delete user from tbl_user
            $deleteQuery = "DELETE FROM tbl_user WHERE username = '$username'";
            if (mysqli_query($conn, $deleteQuery)) {
                echo "success";
            } else {
                echo "error";
            }
        } else {
            echo "error";
        }
    } else {
        echo "error";
    }
}
?>
