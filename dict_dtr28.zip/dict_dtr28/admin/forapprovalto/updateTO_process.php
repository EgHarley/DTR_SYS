<?php
session_start();
include '../../connection.php';

$response = ["success" => false, "message" => "Something went wrong."];

// Check if data is received
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $orig_to_no = $_POST["orig_to_no"];
    $to_no = $_POST["to_no"];
    $dates = $_POST["dates"];
    $purpose = $_POST["purpose"];
    // Debugging: Check if variables are received correctly
    if (empty($to_no) || empty($dates) || empty($purpose)) {
        $response["message"] = "Missing required fields.";
        echo json_encode($response);
        exit();
    }

    // Use prepared statements to avoid SQL injection
    $stmt = $conn->prepare("UPDATE tbl_travel_order SET to_no = ?, dates = ?, purpose = ? WHERE to_no = ?");
    $stmt->bind_param("ssss", $to_no, $dates, $purpose, $orig_to_no);

    if ($stmt->execute()) {
        $response["success"] = true;
        $response["message"] = "User updated successfully.";
    } else {
        $response["message"] = "Database error: " . $stmt->error;
    }

    $stmt->close();
} else {
    $response["message"] = "Invalid request method.";
}

echo json_encode($response);
?>
