<?php
// Prevent accidental output before headers
ob_start();

require '../connection.php'; // Ensure this file exists and the database connection works
require 'fpdf186/fpdf.php'; // Ensure fpdf.php is inside dict_dtr27/admin/exportdtr

// Check if username is provided
$username = $_GET['username'] ?? '';
if (empty($username)) {
    die("Invalid request. Username is missing.");
}

// Fetch user details from tbl_user
$userQuery = "SELECT fname, position, division, designation FROM tbl_user WHERE username = ?";
$userStmt = $conn->prepare($userQuery);
$userStmt->bind_param("s", $username);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userData = $userResult->fetch_assoc();

// Default values if not found
$fname = $userData['fname'] ?? 'N/A';
$position = $userData['position'] ?? 'N/A';
$division = $userData['division'] ?? 'N/A';
$designation = $userData['designation'] ?? 'N/A';

// Fetch attendance records for the user
$query = "SELECT username, time_in, time_out, undertime, record_date FROM attendance_records WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Create a new PDF class extending FPDF
class PDF extends FPDF {
    function Header() {
        // Set font for the title
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'Daily Time Record', 0, 1, 'C');

        // Date of export (Upper right) with formatted date
        $formattedDate = date('F j, Y'); // Example: March 25, 2025
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 10, 'Date: ' . $formattedDate, 0, 1, 'R');
        $this->Ln(5);
    }
}

// Initialize PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, "Username: " . $username, 0, 1);
$pdf->Cell(0, 10, "Full Name: " . $fname, 0, 1);
$pdf->Cell(0, 10, "Position: " . $position, 0, 1);
$pdf->Cell(0, 10, "Division: " . $division, 0, 1);
$pdf->Cell(0, 10, "Designation: " . $designation, 0, 1);
$pdf->Ln(5);

// Table headers
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 10, 'Record Date', 1);
$pdf->Cell(40, 10, 'Time In', 1);
$pdf->Cell(40, 10, 'Time Out', 1);
$pdf->Cell(40, 10, 'Undertime (min)', 1);
$pdf->Ln();

// Table data
$pdf->SetFont('Arial', '', 10);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(40, 10, $row['record_date'], 1);
    $pdf->Cell(40, 10, $row['time_in'] ?? 'N/A', 1);
    $pdf->Cell(40, 10, $row['time_out'] ?? 'N/A', 1);
    $pdf->Cell(40, 10, $row['undertime'], 1);
    $pdf->Ln();
}

// Clear previous output before sending PDF
ob_clean();

// Output PDF to browser
$pdf->Output('D', "DTR_{$username}.pdf");
exit;
?>