<?php
require '../../connection.php'; // Ensure database connection

$search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : "";
$searchFormatted = str_replace("-", "", $search); // Remove dashes

$sort = isset($_POST['sort']) ? $_POST['sort'] : "created_at_desc";

$order_by = "tbl_travel_order.username ASC"; // Default sorting

// Set sorting based on dropdown selection
switch ($sort) {
  case "to_asc":
    $order_by = "to_no ASC";
    break;
  case "to_desc":
    $order_by = "to_no DESC";
    break;
  case "name_asc":
    $order_by = "fname ASC";
    break;
  case "name_desc":
    $order_by = "fname DESC";
    break;
  case "purpose_asc":
    $order_by = "purpose ASC";
    break;
  case "purpose_desc":
    $order_by = "purpose DESC";
    break;
  case "position_asc":
    $order_by = "position ASC";
    break;
  case "position_desc":
    $order_by = "position DESC";
    break;
}

// SQL query with search, sorting, and dash removal in to_no
$query = "SELECT * 
          FROM tbl_travel_order 
          INNER JOIN tbl_user ON tbl_travel_order.username = tbl_user.username 
          WHERE tbl_travel_order.status = 'pending' 
          AND (
            REPLACE(tbl_travel_order.to_no, '-', '') LIKE '%$searchFormatted%'
            OR tbl_travel_order.purpose LIKE '%$search%'
            OR tbl_user.fname LIKE '%$search%'
            OR tbl_travel_order.username LIKE '%$search%'
          ) 
          ORDER BY $order_by";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    $name = $row['fname'];

    echo "<tr>
            <td style='background-color: #DEDEDE; color: black;'>{$row['to_no']}</td>
            <td style='background-color: #DEDEDE; color: black;'>{$name}</td>
            <td style='background-color: #DEDEDE; color: black;'>{$row['purpose']}</td>
            <td style='background-color: #DEDEDE; color: black;'>
                              <button class='btn btn-primary btn-sm' style='background-color: #10346C; color: white; border-color: #10346C;' onclick='viewTO(\"{$row['to_no']}\")' title='View Travel Order'>
                                  <i class='fa-solid fa-eye'></i>
                              </button>

                              <button class='btn btn-primary btn-sm' style='background-color: #10346C; color: white; border-color: #10346C;' onclick='updateTO(\"{$row['to_no']}\")' title='Edit Travel Order'>
                                  <i class='fa-solid fa-pen-to-square'></i>
                              </button>
                              
                              <button class='btn btn-primary btn-sm' 
                                style='background-color: #10346C; color: white; border-color: #10346C;' 
                                onclick='approveTO(\"{$row['to_no']}\")' 
                                title='Approve Travel Order'>
                                <i class='fa-solid fa-check'></i>
                              </button>

                              <button class='btn btn-danger btn-sm' 
                                style='background-color: #E60000; color: white; border-color: #E60000;' 
                                onclick='declineTO(\"{$row['to_no']}\")' 
                                title='Decline Travel Order'>
                                <i class='fa-solid fa-xmark'></i>
                              </button>
            </td>
          </tr>";
  }
} else {
  echo "<tr><td colspan='5' class='text-center'>No records found.</td></tr>";
}
?>

<script> //approve to
    function approveTO(to_no) {
      Swal.fire({
        title: "Are you sure you want to approve this Travel Order?",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes",
        cancelButtonText: "No"
      }).then((result) => {
        if (result.isConfirmed) {
          fetch("approve_TO/approve_TO.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "to_no=" + encodeURIComponent(to_no)
          })
            .then(response => response.json())
            .then(data => {
              if (data.status === "success") {
                Swal.fire({
                  title: "Travel Order Approved Successfully!",
                  icon: "success",
                  timer: 1090, 
                  showConfirmButton: false
                }).then(() => {
                  window.location.href = "forapprovalto.php"; // Redirect after success
                });
              } else {
                Swal.fire("Error!", data.message, "error");
              }
            })
            .catch(error => {
              console.error("Error:", error);
              Swal.fire("Error!", "Something went wrong.", "error");
            });
        }
      });
    }
</script>

<script> //deccline to
    function declineTO(to_no) {
      Swal.fire({
        title: "Are you sure you want to decline this travel order?",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes",
        cancelButtonText: "No"
      }).then((result) => {
        if (result.isConfirmed) {
          fetch("decline_TO/decline_TO.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "to_no=" + encodeURIComponent(to_no)
          })
            .then(response => response.json())
            .then(data => {
              if (data.status === "success") {
                Swal.fire({
                  title: "Travel Order Declined Successfully!",
                  icon: "success",
                  timer: 1100,
                  showConfirmButton: false
                }).then(() => {
                  window.location.href = "forapprovalto.php"; // Redirect
                });
              } else {
                Swal.fire("Error!", data.message, "error");
              }
            })
            .catch(error => {
              console.error("Error:", error);
              Swal.fire("Error!", "Something went wrong.", "error");
            });
        }
      });
    }
</script>