<?php
$host = "localhost"; // Change if needed
$user = "root"; // Change if needed
$pass = ""; // Change if needed
$dbname = "db_dtr1";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>




<?php

/*
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function getUserLocation($ip) {
    $apiKey = "uname"; // Replace with your actual API key
    $apiUrl = "http://ip-api.com/json/$ip?key=$apiKey";
    
    $response = json_decode(file_get_contents($apiUrl), true);
    
    if ($response['status'] === 'success') {
        return array($response['lat'], $response['lon']);
    } else {
        return null;
    }
}

function isLocationAllowed($userLocation, $allowedLocation) {
    // Calculate distance between two points (simplified example)
    $distance = sqrt(pow($userLocation[0] - $allowedLocation[0], 2) + pow($userLocation[1] - $allowedLocation[1], 2));
    
    // Define a radius for allowed access (e.g., 1 km)
    $allowedRadius = 0.01; // Approximate 1 km in latitude/longitude degrees
    
    return $distance <= $allowedRadius;
}

$allowedLocation = array(16.59190569801962, 120.32239627084316); // Example allowed location (San Francisco)

$userIP = getUserIP();
$userLocation = getUserLocation($userIP);

if ($userLocation && isLocationAllowed($userLocation, $allowedLocation)) {
    echo "Access granted from location: " . $userLocation[0] . ", " . $userLocation[1];
} else {
    echo "Access denied. You must access this system from the authorized location.";
}




// Function to get the user's IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
//Specific address of DICTRO1  (16.61248499447441, 120.31635415589538)
// Function to check if the IP is in a specific range
function isIPAllowed($ip, $allowedIPs) {
    foreach ($allowedIPs as $allowedIP) {
        if ($ip === $allowedIP) {
            return true;
        }
    }
    return false;
}

// Main logic
//$allowedIPs = array("192.168.1.100", "192.168.1.101"); // Example allowed IPs
$allowedIPs = array("192.168.100.100", "192.168.1.101"); // Example allowed IPs

$userIP = getUserIP();

if (isIPAllowed($userIP, $allowedIPs)) {
    echo "Access granted from IP: $userIP";
} else {
    echo "Access denied from IP: $userIP";
}
*/
?>

