<?php
session_start();
include '../../connection.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $fname = $_POST['fname'];
    $division = $_POST['division'];
    $designation = $_POST['designation'];
    $position = $_POST['position'];
    $password = $_POST['password']; // No password_hash()

    // Prepare the update query
    $stmt = $conn->prepare("UPDATE tbl_user SET fname = ?, division = ?, designation = ?, position = ?, password = ? WHERE username = ?");
    $stmt->bind_param("ssssss", $fname, $division, $designation, $position, $password, $username);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update user."]);
    }

    $stmt->close();
    $conn->close();
}
?>
