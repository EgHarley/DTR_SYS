<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}

include '../include/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
    <script>
        function updateDateTime() {
            const now = moment();
            document.getElementById('date-time-form').innerHTML = 
                `<span style="color: black;">${now.format('dddd, MMMM D, YYYY')}</span><br>
                 <span style="color: #a70000; font-size: 45px">${now.format('hh:mm:ss A')}</span>`;
        }

        setInterval(updateDateTime, 1000);

        window.onload = function() {
            <?php if (isset($_SESSION['error'])): ?>
                document.getElementById('error-message').innerText = "<?php echo $_SESSION['error']; ?>";
                document.getElementById('error-message').style.display = 'block';
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
        };
    </script>
    <style>
        body {
            background: linear-gradient(to bottom, #ffffff 0%, #ffffff 68%, #10346C 100%);
            background-size: cover;
            background-attachment: fixed;
        }

        .card {
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
            background-color: #D9D9D6 !important;
            border-radius: 10px;
        }

        #error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .btn-primary {
            background-color: #10346C !important;
            border-color: #10346C !important;
            border-radius: 10px;
        }

        .btn-apply-to {
            background-color: white !important;
            color: #10346C !important;
            border: 2px solid #10346C !important;
            border-radius: 10px;
        }

        .btn-apply-to:hover {
            background-color: #10346C !important;
            color: white !important;
        }

        input.form-control {
            border: 1px solid black;
            border-radius: 10px;
        }

        .logo-container {
            text-align: center;
            margin-bottom: 15px;
            margin-top: -30px;
        }

        .logo-container img {
            width: 110px;
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="logo-container">
            <img src="../images/DICT.png" alt="DICT Logo">
            <img src="../images/bagong_pinas.png" alt="Bagong Pilipinas Logo">
        </div>

        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Administrator</h3>
                    </div>
                    <div class="card-body">
                        <div class="datetime-box text-center">
                            <p id="date-time-form">Loading...</p>
                        </div>

                        <div id="error-message"></div>

                        <form action="login_process.php" method="POST">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="fas fa-user"></i> Username
                                </label>
                                <input type="text" name="username" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="fas fa-lock"></i> Password
                                </label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <!-- <p class="text-center mt-3">
                                You don't have an account yet? <a href="register/register.php">Click to Register</a>
                            </p> -->
                            <button type="submit" class="btn btn-primary w-100 mb-2">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        updateDateTime();
    </script>
</body>
</html>
