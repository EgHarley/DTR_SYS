<?php
session_start();
include '../../../connection.php';

$response = ["success" => false, "message" => "Something went wrong."];

// Check if data is received
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $uname = $_POST["uname"];
    $username = $_POST["username"];
    $fullname = $_POST["fname"];
    $division = $_POST["division"];
    $designation = $_POST["designation"];
    $position = $_POST["position"];

    // Debugging: Check if variables are received correctly
    if (empty($username) || empty($fullname)) {
        $response["message"] = "Missing required fields."; 
        echo json_encode($response);
        exit();
    }

    // Use prepared statements to avoid SQL injection
    $stmt = $conn->prepare("UPDATE tbl_registration SET username = ?, fname = ?, division = ?, designation = ?, position = ? WHERE username = ?");
    $stmt->bind_param("ssssss", $username, $fullname, $division, $designation, $position, $uname);

    if ($stmt->execute()) {
        $response["success"] = true;
        $response["message"] = "User updated successfully.";
    } else {
        $response["message"] = "Database error: " . $stmt->error;
    }

    $stmt->close();
} else {
    $response["message"] = "Invalid request method.";
}

echo json_encode($response);
?>