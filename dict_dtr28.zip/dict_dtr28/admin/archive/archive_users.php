<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
include '../../connection.php';

// Handle Unarchive
if (isset($_POST['unarchive_id'])) {
    $archived_id = intval($_POST['unarchive_id']);
    $getData = mysqli_query($conn, "SELECT * FROM tbl_archived_user WHERE arch_id = $archived_id");
    if ($row = mysqli_fetch_assoc($getData)) {
        // Restore ALL fields that exist in tbl_user
        $insert = mysqli_query($conn, "INSERT INTO tbl_user 
            (username, password, fname, division, designation, position, ulvl, remaining_days) 
            VALUES (
                '" . $row['username'] . "', 
                '" . $row['password'] . "', 
                '" . $row['fname'] . "', 
                '" . $row['division'] . "', 
                '" . $row['designation'] . "', 
                '" . $row['position'] . "', 
                '" . $row['ulvl'] . "', 
                '" . $row['remaining_days'] . "'
            )");

        if ($insert) {
            mysqli_query($conn, "DELETE FROM tbl_archived_user WHERE arch_id = $archived_id");
            echo json_encode(['status' => 'success', 'message' => 'User unarchived successfully.']);
            exit();
        }
    }
    echo json_encode(['status' => 'error', 'message' => 'Failed to unarchive user.']);
    exit();
}


// Handle Permanent Delete
if (isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $delete = mysqli_query($conn, "DELETE FROM tbl_archived_user WHERE arch_id = $delete_id");
    if ($delete) {
        echo json_encode(['status' => 'success', 'message' => 'User deleted permanently.']);
        exit();
    }
    echo json_encode(['status' => 'error', 'message' => 'Failed to delete user.']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Users Archive</title>
    <link rel="icon" type="image/x-icon" href="../../images/LOGO.ico">
    <link rel="stylesheet" href="../../sidebar/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<style>
    body {
        font-family: Arial, sans-serif;
    }

    ul.nav-list {
        padding-left: 0;
    }

    .dropdown-links {
        display: none;
        list-style-type: none;
        padding-left: 20px;
    }

    .dropdown-links {
    display: none;
    }

    .dropdown.active .dropdown-links {
        display: block;
    }


    .dropdown-links li {
        margin: 5px 0;
    }

    .dropdown-links a {
    text-decoration: none;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px;
    border-radius: 5px;
    width: 30px;
    height: 30px;
    transition: background-color 0.3s ease;
    }

    .dropdown-links a:hover {
        color: #007bff;
    }

    .icon {
        display: block;
        margin: 75px auto 0;
        width: 200px;
        height: auto;
    }

    #btn {
        height: 90px;
    }

    .user-info-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        margin-top: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
        color: #000;
    }

    .current-date {
        color: #000;
        font-size: 16px;
    }

    .card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-top: -55px;
    }

    table {
        width: 100%;
        margin-top: 40px;
        border-collapse: collapse;
        border: 1px solid #ccc;
    }

    table th,
    table td {
        padding: 15px;
        border: 1px solid #ccc;
        text-align: center;
    }

    table th {
        background-color: #10346C;
        color: white;
        font-size: 18px;
    }

    table td {
        font-size: 16px;
        background-color: #DEDEDE;
        color: black;
    }

    .dropdown-links a.active {
    background-color: #10346C;
    color: #fff !important;
    }

</style>

<body>
<div class="sidebar">
                <div class="logo_details">
                    <img src="../../images/dict_logo.png" alt="Logo" class="icon">
                    <i class="bx bx-menu" id="btn"></i>
                </div><br><br>
                <ul class="nav-list">
        <li>
            <a href="../exportdtr/exportdtr.php" title="Export DTR">
            <i class="fa-solid fa-calendar-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../approvedto/approvedto.php" title="Approved TOs">
            <i class="fa-solid fa-file-circle-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../approveduser/approveduser.php" title="Approved Users">
            <i class="fa-solid fa-user-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../forapprovalto/forapprovalto.php" title="For Approval of TOs">
            <i class="fa-solid fa-file-circle-exclamation fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../forapprovaluser/approvaluser.php" title="For Approval of Users">
            <i class="fa-solid fa-user-plus fa-xl"></i>
            </a>
        </li>

        <!-- Archive Dropdown Only Icons -->
        <li class="dropdown">
            <a href="#" title="Archive"><i class="fa-solid fa-box-archive fa-xl"></i></a>
            <ul class="dropdown-links">
            <li><a href="archive_to.php" title="TO Archive"><i class="fa-solid fa-file"></i></a></li>
            <li><a href="archive_dtr.php" title="DTR Archive"><i class="fa-solid fa-calendar"></i></a></li>
            <li><a href="archive_users.php" title="Users Archive"><i class="fa-solid fa-users"></i></a></li>
            </ul>
        </li>
        </ul>
    </div>

<section class="home-section">
    <?php include '../../include/header.php'; ?>
    <div class="user-info-container">
        <div class="user-info">
            <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C;"></i>
            <span>Logged in as <?php echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']); ?></span>
            <a href="../logout_admin.php" class="ms-3" style="text-decoration: none;"><i class="fa fa-lock"></i> Logout</a>
        </div>
        <div class="current-date d-flex align-items-center">
            <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
            <span id="current-date"></span>
        </div>
    </div>

    <br><br>

    <main class="px-3 py-2" style="background-color: #e6e4e4;">
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-header d-flex align-items-center">
                    <i class="fa-solid fa-box-archive me-2 fs-4"></i>
                    <span class="fw-bold fs-4">Archived Users</span>
                </div>
                <div class="card-body" style="max-height: 505px; overflow-y: auto; border: 1px solid #ccc;">
                    <?php
                    $query = "SELECT * FROM tbl_archived_user ORDER BY arch_id DESC";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        echo "<div class='table-responsive'><table class='table table-hover'>";
                        echo "<thead><tr>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Position</th>
                                <th>Actions</th>
                              </tr></thead><tbody>";
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['fname']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['position']) . "</td>";
                            echo "<td>
                                    <button class='btn btn-primary btn-sm view-btn' data-id='{$row['arch_id']}'>
                                        <i class='fa-solid fa-eye'></i> View
                                    </button>
                                    <button class='btn btn-success btn-sm unarchive-btn' data-id='{$row['arch_id']}'>
                                        <i class='fa-solid fa-box-open'></i> Unarchive
                                    </button>
                                    <button class='btn btn-danger btn-sm delete-btn' data-id='{$row['arch_id']}'>
                                        <i class='fa-solid fa-trash'></i> Delete
                                    </button>
                                  </td>";
                            echo "</tr>";
                        }
                        echo "</tbody></table></div>";
                    } else {
                        echo "<p>No archived users found.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </main>
</section>


<script>

    // CLOCK FUNCTION
    function updateClock() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
    }
    setInterval(updateClock, 1000);
    updateClock();

    // jQuery on ready
    $(document).ready(function () {

        // UNARCHIVE FUNCTION - NOW AJAX WITH SWEETALERT POPUP
        $(document).on('click', '.unarchive-btn', function () {
            const id = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "User will be unarchived.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, unarchive!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'unarchive_user.php',
                        type: 'GET',
                        data: { unarchive_id: id },
                        dataType: 'json',
                        success: function (response) {
                            Swal.fire(
                                response.status === 'success' ? 'Success' : 'Error',
                                response.message,
                                response.status
                            ).then(() => {
                                if (response.status === 'success') location.reload();
                            });
                        },
                        error: function (xhr, status, errorThrown) {
                        console.log('AJAX Error:', status, errorThrown);
                        console.log('Response:', xhr.responseText);
                        Swal.fire('Error', 'Failed to connect to the server.', 'error');
                    }
                    });
                }
            });
        });

        // DELETE FUNCTION
        $(document).on('click', '.delete-btn', function () {
            const id = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "User will be deleted permanently.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('delete_user.php', { delete_id: id }, function (response) {
                        const res = JSON.parse(response);
                        Swal.fire(res.status === 'success' ? 'Deleted!' : 'Error', res.message, res.status);
                        if (res.status === 'success') location.reload();
                    });
                }
            });
        });

    });
</script>

<script src="../../sidebar/sidebar.js"></script>

<script>
$(document).on('click', '.view-btn', function () {
    let userId = $(this).data('id'); // Get the user ID from button

    if (!userId) {
        Swal.fire('Error', 'Invalid user ID.', 'error');
        return;
    }

    $.ajax({
        url: 'get_user_details.php',
        type: 'GET',
        data: { user_id: userId }, 
        dataType: 'json',
        success: function (response) {
            if (response.status === 'success') {
                $('#viewUsername').text(response.data.username);
                $('#viewFullname').text(response.data.fname);
                $('#viewDivision').text(response.data.division);
                $('#viewDesignation').text(response.data.designation);
                $('#viewPosition').text(response.data.position);
                $('#viewUserLevel').text(response.data.ulvl);
                $('#hashedPassword').text('********').data('password', response.data.password);

                $('#viewUserModal').modal('show');
            } else {
                Swal.fire('Error', response.message, 'error');
            }
        },
        error: function () {
            Swal.fire('Error', 'Failed to retrieve user details.', 'error');
        }
    });
});

$(document).ready(function () {
    $('#togglePassword').click(function () {
        let passwordField = $('#hashedPassword');
        let icon = $(this).find('i'); 

        if (passwordField.text() === '********') {
            // Show actual password
            passwordField.text(passwordField.data('password'));
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            // Hide password
            passwordField.text('********');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
});

</script>

<!-- View User Modal -->
<div class="modal fade" id="viewUserModal" tabindex="-1" aria-labelledby="viewUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewUserModalLabel">User Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tr><th>Username</th><td id="viewUsername"></td></tr>
                    <tr><th>Full Name</th><td id="viewFullname"></td></tr>
                    <tr><th>Division</th><td id="viewDivision"></td></tr>
                    <tr><th>Designation</th><td id="viewDesignation"></td></tr>
                    <tr><th>Position</th><td id="viewPosition"></td></tr>
                    <tr><th>User Level</th><td id="viewUserLevel"></td></tr>
                    <tr>
                        <th>Password</th>
                        <td>
                            <span id="hashedPassword">********</span>
                            <button type="button" class="btn btn-sm btn-secondary" id="togglePassword">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>
