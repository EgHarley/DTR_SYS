<!-- Include SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // SweetAlert confirmation and form submission
    document.getElementById("ApplyTO").addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent form from submitting immediately

        // Check if the username validation message is "Invalid Username"
        let errorMessage = document.querySelector("#username-validation"); // Ensure this ID is used in your PHP response
        if (errorMessage && errorMessage.innerText.includes("Invalid Username")) {
            Swal.fire({
                title: "Invalid Username",
                text: "Please enter a valid username before proceeding.",
                icon: "error",
                confirmButtonColor: "#E60000"
            });
            return; // Stop further execution
        }

        Swal.fire({
            title: "Are you sure you want to save this travel order?",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#10346C",
            cancelButtonColor: "#E60000",
            confirmButtonText: "Yes"
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Successfully Added!",
                    icon: "success",
                    timer: 1000,
                    showConfirmButton: false
                });

                // Submit the form after 1 second
                setTimeout(() => {
                    e.target.submit();
                }, 1000);

                // Redirect to another page after 1.5 seconds
                setTimeout(() => {
                    window.location.href = "../index.php";
                }, 1500);
            }
        });
    });
</script>

<!-- Back to Home -->
<script>
    function confirmBackToHome() {
        let form = document.getElementById("ApplyTO"); // Change this to your form's ID
        let inputs = form.querySelectorAll("input, textarea, select");
        let hasInput = Array.from(inputs).some(input => input.value.trim() !== "");

        if (!hasInput) {
            // If there are no inputs, redirect immediately
            window.location.href = '../index.php';
            return;
        }

        // If there are inputs, show confirmation
        Swal.fire({
            title: "<span style='font-size: 28.5px;'>Are you sure you want to go back?</span>",
            html: "If you go back now, you will lose any <br> changes you've made.",
            icon: "question",
            showCancelButton: true,
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            reverseButtons: false,
            customClass: {
                title: 'swal-title-custom'
            },
            didOpen: () => {
                let confirmBtn = document.querySelector(".swal2-confirm");
                let cancelBtn = document.querySelector(".swal2-cancel");

                confirmBtn.style.backgroundColor = "#10346C";
                confirmBtn.style.marginRight = "8px";
                confirmBtn.style.width = "80px";
                confirmBtn.style.padding = "8px 16px";
                confirmBtn.style.borderRadius = "8px";
                confirmBtn.style.borderColor = "#10346C";

                cancelBtn.style.backgroundColor = "#E60000";
                cancelBtn.style.marginRight = "8px";
                cancelBtn.style.width = "80px";
                cancelBtn.style.padding = "8px 16px";
                cancelBtn.style.borderRadius = "8px";
                cancelBtn.style.borderColor = "#E60000";
            }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../index.php'; // Redirect to home
            }
        });
    }
</script>

<style>
    .swal-title-custom {
        font-size: 28.5px !important;
    }
</style>