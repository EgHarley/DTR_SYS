document.getElementById("logoutLink").addEventListener("click", function (event) {
    event.preventDefault(); // Prevent immediate navigation

    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "custom-confirm-button btn",
        cancelButton: "custom-cancel-button btn"
      },
      buttonsStyling: false
    });

    swalWithBootstrapButtons.fire({
      title: "Are you sure you want <br> to log out?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        swalWithBootstrapButtons.fire({
          title: "Successfully logged out!",
          icon: "success",
          showConfirmButton: false, // Remove "OK" button
          timer: 2000, // Auto-close after 2 seconds
          timerProgressBar: true // Show progress bar
        });

        setTimeout(() => {
          window.location.href = "logout.php"; // Redirect after 2 seconds
        }, 1090);
      }
    });
  });