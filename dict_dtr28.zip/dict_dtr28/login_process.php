<?php
session_start();
require 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Username and Password are required.";
        header("Location: index.php");
        exit();
    }

    // Check if the username and password match in tbl_user
    $query = "SELECT username, password, fname, ulvl, status FROM tbl_user WHERE BINARY username = ? AND BINARY password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_username, $db_password, $fname, $ulvl, $status);
        $stmt->fetch();

        if ($status === 'Approved') {
            $_SESSION['username'] = $db_username;
            $_SESSION['fullname'] = $fname;
            $_SESSION['ulvl'] = $ulvl;

            // Redirect based on user level
            if ($ulvl === 'Administrator') {
                header("Location: admin/exportdtr/exportdtr.php");
            } else {
                header("Location: dashboard.php");
            }
            exit();
        } else {
            $_SESSION['error'] = "Your account is still awaiting approval from the Administrator.";
            header("Location: index.php");
            exit();
        }
    }

    // If not found in tbl_user, check tbl_registration
    $query = "SELECT username, password, fname, status FROM tbl_registration WHERE BINARY username = ? AND BINARY password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_username, $db_password, $fname, $status);
        $stmt->fetch();

        if ($status === 'Pending') {
            $_SESSION['error'] = "Your account is still awaiting approval from the Administrator.";
        } else {
            $_SESSION['error'] = "Incorrect username or password.";
        }
    } else {
        $_SESSION['error'] = "Incorrect username or password.";
    }

    header("Location: index.php");
    exit();
}
?>




