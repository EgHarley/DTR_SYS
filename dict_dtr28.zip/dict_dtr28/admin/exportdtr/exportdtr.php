<?php
session_start();
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// include 'include/header.php'
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Export DTR</title>
  <link rel="icon" type="image/x-icon" href="../../images/LOGO.ico">
  <link rel="stylesheet" href="../../sidebar/style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <!-- sweet alert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
  body {
    font-family: Arial, sans-serif;
  }

  ul.nav-list {
    padding-left: 0rem;
  }

  .dropdown-links {
    display: none;
    /* Hide the links by default */
    list-style-type: none;
    padding-left: 20px;
  }

  /* Show dropdown on hover */
  .dropdown:hover .dropdown-links {
    display: block;
  }

  .dropdown-links li {
    margin: 5px 0;
  }

  .dropdown-links a {
    text-decoration: none;
    color: white;
  }

  .dropdown-links a:hover {
    color: #007bff;
    /* Change color on hover */
  }

  .icon {
    display: block;
    margin: 75px auto 0;
    width: 200px;
    height: auto;
  }

  #btn {
    height: 90px;
    /* Adjust height */
    /* line-height: 100px;  */
  }

  .user-info-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    margin-top: 10px;
  }

  .user-info {
    display: flex;
    align-items: center;
    color: #000;
  }

  .current-date {
    color: #000;
    font-size: 16px;
  }

  .card {
    background: #fff;
    border-radius: 10px;
    margin-top: -55px;
  }

  .time-display {
    font-size: 72px;
    font-weight: bold;
    margin: 5px 0;
    /* font-family: Digital-7 mono; */
  }

  .time-buttons button {
    padding: 15px 30px;
    margin: 10px;
    font-size: 18px;
    border-radius: 8px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
  }

  .time-buttons button:disabled {
    background-color: #6c757d !important;
    /* Gray color */
    border-color: #6c757d !important;
    cursor: not-allowed;
    opacity: 0.65;
    /* Slight transparency */
  }

  table {
    width: 100%;
    margin-top: 40px;
    border-collapse: collapse;
    
  }

  table th,
  table td {
    padding: 15px;
    border: 1px solid #dee2e6;
    text-align: center;
  }

  table th {
    background-color: #f1f1f1;
    font-size: 18px;
  }

  table td {
    font-size: 16px;
    
  }
  
  .card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    margin-top: -55px;
  }


  /* history button */
  .history-btn {
    background-color: #10346C !important;
    border-color: #10346C !important;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
  }

  .history-btn:hover {
    background-color: #0c2957 !important;
    border-color: #0c2957 !important;
  }

  .custom-confirm-button {
    background-color: #10346C !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }

  .custom-cancel-button {
    background-color: #E60000 !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }
@media (max-width: 768px) {
  .container-fluid .card .card-header .d-flex .form-select {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
    padding: 10px;
    box-sizing: border-box;
  }

  .d-flex.mb-3 {
    flex-direction: column;
  }

  .d-flex.mb-3 select,
  .d-flex.mb-3 button {
    width: 100%;
    margin-bottom: 10px;
  }
  
  .card-body {
      padding: 10px;
    }
}
 
</style>

<body>
  <div class="sidebar">
  <div class="logo_details">
      <i class="fa-solid fa-circle-user" id="btn" style="color: #10346C; "></i>
    <span class="icon">
          <?php
          //echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
          echo  htmlspecialchars($_SESSION['fullname']);
          ?>
        </span>
    </div><br><br>
    
    <ul class="nav-list">
      <li>
        <a href="exportdtr.php" class="active">
          <i class="fa-solid fa-calendar-check" title="Export DTR"></i>
          <span class="link_name">Export DTR</span>
        </a>
      </li>
      <li>
        <a href="../approvedto/approvedto.php" title="Approved TOs">
          <i class="fa-solid fa-file-circle-check"></i>
          <span class="link_name">Approved TOs</span>
        </a>
      </li>
      <li>
        <a href="../approveduser/approveduser.php" title="Approved Users">
          <i class="fa-solid fa-user-check"></i>
          <span class="link_name">Approved Users</span>
        </a>
      </li>
      <li>
        <a href="../forapprovalto/forapprovalto.php" title="For Approval of TOs">
          <i class="fa-solid fa-file-circle-exclamation"></i>
          <span class="link_name">For Approval of TOs</span>
        </a>
      </li>
      <li>
        <a href="../forapprovaluser/approvaluser.php" title="For Approval of Users">
          <i class="fa-solid fa-user-plus"></i>
          <span class="link_name">For Approval of Users</span>
        </a>
      </li>
      <li>
      <a href="../archive/archive_to.php" title="Archive">
          <i class="fa-solid fa-box-archive"></i>
          <span class="link_name">Archive</span>
        </a>
      </li><br><br><br><br><br><br><br><br><br><br>
      
      <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
    </ul>
    <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; ">
          <span style="color: #10346C";>Logout</span>
        </a>
  </div>

  <section class="home-section">

    <?php include '../../include/header.php'; ?>

    <div class="user-info-container">
    <div class="user-info">
      <img src="../../images/bagong_pinas.png" alt="User Image" style="width: 100%; max-width: 50px; height: auto; display: block; margin-left: 20px; margin-bottom: 1px; margin-top: -10px;">
      <img src="../../images/dict_logo.png" alt="User Image" style="width: 100%; max-width: 100px; height: auto; display: block; margin-left: 20px;margin-top: -10px;">
      </div>

      <div class="current-date d-flex align-items-center">
        <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
        <span id="current-date"></span>
      </div>
    </div>

    <br><br>

    <!-- main dash contents -->
    <main class="px-3 py-2" style="background-color: #e6e4e4;">
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
              <i class="fa-solid fa-calendar-check me-2 fs-4"></i>
              <span class="fw-bold fs-4">Export DTR</span>
            </div>
            <div class="d-flex">
              <!-- Sort Dropdown -->
              <select id="sortDropdown" class="form-select me-2" style="width: 200px; border: 1px solid #ccc;">
                <option value="" disabled selected>Sort by</option>
                <option value="to_asc">T.O. Number (A-Z)</option>
                <option value="to_desc">T.O. Number (Z-A)</option>
                <option value="name_asc">Name (A-Z)</option>
                <option value="name_desc">Name (Z-A)</option>
                <option value="purpose_asc">Purpose (A-Z)</option>
                <option value="purpose_desc">Purpose (Z-A)</option>
              </select>

              <!-- Search Input -->
              <div class="input-group">
                <span class="input-group-text" style="border: 1px solid #ccc;"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" id="searchInput" class="form-control" style="width: 150px; border: 1px solid #ccc;" placeholder="Search...">
              </div>
            </div>
          </div>
          <div class="card-body">
            <!-- Filters Section -->
            <div class="d-flex mb-3">
              <select id="yearDropdown" style="border-radius: 10px; width: 10%; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);" class="form-select me-2">
                <option value="">Year</option>
              </select>

              <select id="monthDropdown" style="border-radius: 10px; width: 15%; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);" class="form-select me-2">
                <option value="">Month</option>
              </select>

              <select id="periodDropdown" style="border-radius: 10px; width: 15%; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);" class="form-select me-2">
                <option value="">Period</option>
                <option value="1st Half">1st Half</option>
                <option value="2nd Half">2nd Half</option>
              </select>

              <select id="designationDropdown" style="border-radius: 10px; width: 15%; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);" class="form-select me-2">
                <option value="">Designation</option>
              </select>

              <select id="divisionDropdown" style="border-radius: 10px; width: 15%; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);" class="form-select me-2">
                <option value="">Division</option>
              </select>

              <div>
                <button id="showButton" class="btn btn-primary" style="background-color: #10346C; border-color: #10346C; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);">Show</button>
              </div>
              <div>
                <button id="exportButton" class="btn btn-primary" style="background-color: #10346C; border-color: #10346C; margin-left: 10px; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);">Export</button>
              </div>
            </div>  

            <!-- User Table -->
            <div class="table-responsive">
              <table class="table table-hover" style="background-color: #DEDEDE;">
                <thead>
                  <tr>
                    <th style="background-color: #10346C; color: white;">Full Name</th>
                    <th style="background-color: #10346C; color: white;">Designation</th>
                    <th style="background-color: #10346C; color: white;">Division</th>
                    <th style="background-color: #10346C; color: white;">Action</th>
                  </tr>
                </thead>
                <tbody id="userTable" style="background-color: #DEDEDE;">
                  <!-- Data will be inserted here via AJAX -->
                </tbody>
              </table>
            </div>
          </div>
        </div>



<!-- JavaScript for Dynamic Filtering -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
    // Load dropdown options
    $.ajax({
        url: "load_filters.php",
        method: "GET",
        dataType: "json",
        success: function (data) {
            data.years.forEach(year => {
                $('#yearDropdown').append(`<option value="${year}">${year}</option>`);
            });

            data.months.forEach(month => {
                $('#monthDropdown').append(`<option value="${month}">${month}</option>`);
            });

            data.designations.forEach(designation => {
                $('#designationDropdown').append(`<option value="${designation}">${designation}</option>`);
            });

            data.divisions.forEach(division => {
                $('#divisionDropdown').append(`<option value="${division}">${division}</option>`);
            });

            // Set defaults
            $('#yearDropdown').val(data.years[0]); // Latest year
            $('#monthDropdown').val(data.months[0]); // Latest month
            $('#periodDropdown').val("2nd Half"); // Default period
            $('#designationDropdown').val("La Union"); // Default designation
            $('#divisionDropdown').val("TOD"); // Default division

            fetchFilteredData(); // Auto-load table with default filters
        }
    });

    // Fetch filtered data on button click
    $('#showButton').on('click', function () {
        fetchFilteredData();
    });

    function fetchFilteredData() {
        let year = $('#yearDropdown').val();
        let month = $('#monthDropdown').val();
        let period = $('#periodDropdown').val();
        let designation = $('#designationDropdown').val();
        let division = $('#divisionDropdown').val();

        $.ajax({
            url: "fetch_filtered_data.php",
            method: "GET",
            data: { year, month, period, designation, division },
            success: function (data) {
                $('#userTable').html(data);
            }
        });
    }
});

function viewDTR(username) {
    window.location.href = "view_dtr.php?username=" + encodeURIComponent(username);
}
</script>


  <!-- Scripts -->
  <script src="../../sidebar/sidebar.js"></script>


    <!-- view button -->
    <script>
    function viewDTR(username) {
      window.location.href = "view_dtr.php?username=" + encodeURIComponent(username);
    }
  </script>

    <!-- search -->
    <script>
    document.getElementById("searchInput").addEventListener("keyup", function () {
      let searchValue = this.value;

      // AJAX Request
      let xhr = new XMLHttpRequest();
      xhr.open("POST", "search_user.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          document.getElementById("userTable").innerHTML = xhr.responseText;
        }
      };
      xhr.send("search=" + encodeURIComponent(searchValue));
    });
  </script>

  <!-- sort -->
  <script>
    function fetchUsers() {
      let searchValue = document.getElementById("searchInput").value;
      let sortValue = document.getElementById("sortDropdown").value;

      let xhr = new XMLHttpRequest();
      xhr.open("POST", "search_user.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          document.getElementById("userTable").innerHTML = xhr.responseText;
        }
      };

      xhr.send("search=" + encodeURIComponent(searchValue) + "&sort=" + encodeURIComponent(sortValue));
    }

    // Attach event listeners
    document.getElementById("searchInput").addEventListener("keyup", fetchUsers);
    document.getElementById("sortDropdown").addEventListener("change", fetchUsers);
  </script>

  <!-- clock -->
  <script>
    function updateClock() {
      const now = new Date();
      const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
      document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
    }

    setInterval(updateClock, 1000);

    // Call it immediately to display the time without delay
    updateClock();
  </script>

  <!-- Logout Script -->
  <script>
    document.getElementById("logoutLink").addEventListener("click", function (event) {
      event.preventDefault(); // Prevent immediate navigation

      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: "custom-confirm-button btn",
          cancelButton: "custom-cancel-button btn"
        },
        buttonsStyling: false
      });

      swalWithBootstrapButtons.fire({
        title: "Are you sure you want <br> to log out?",
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        reverseButtons: false
      }).then((result) => {
        if (result.isConfirmed) {
          swalWithBootstrapButtons.fire({
            title: "Successfully logged out!",
            icon: "success",
            showConfirmButton: false, // Remove "OK" button
            timer: 2000, // Auto-close after 2 seconds
            timerProgressBar: true // Show progress bar
          });

          setTimeout(() => {
            window.location.href = "../logout_admin.php"; // Redirect after 2 seconds
          }, 1090);
        }
      });
    });
  </script>

</body>
</html>