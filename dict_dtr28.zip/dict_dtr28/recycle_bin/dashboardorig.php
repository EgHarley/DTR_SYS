<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include header
include 'include/header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* Sidebar Styles */
        .sidebar {
            background-color: #D2CCCC !important;
            height: 100vh;
            padding-top: 20px;
            border-right: 1px solid #aaa;
            position: fixed; /* Fixing the sidebar */
            top: 0;
            left: 0;
            width: 250px; /* Adjust width if necessary */
            z-index: 1000; /* Ensures the sidebar is above content */
        }

        .sidebar img {
            width: 200px;
            height: auto;
            display: block;
            margin: 0 auto 10px;
        }

        .nav-link {
            color: #5A6670 !important;
            font-size: 16px;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: 0.3s;
            font-weight: bold;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 18px;
        }

        .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .nav-item.active .nav-link {
            background-color: #5A6670 !important;
            color: white !important;
            border-radius: 5px;
        }

        .nav-item:not(.active) .nav-link {
            color: #5A6670 !important;
        }

        /* Main content */
        main {
            margin-left: 260px; /* Adjust for sidebar width */
            padding-top: 20px;
        }

        .container-bordered {
            border: 1px solid black;
            padding: 20px;
        }

        /* Position the user info outside the container */
        .user-info {
            position: fixed;
            top: 20px;
            font-size: 14px;
            color: #000000;
            padding: 79px 280px;
        }

        .user-info i {
            margin-right: 3px; /* Space between icon and text */
            font-size: 20px; /* Adjust the size of the icon */
            color: #10346C; /* Change the icon color */
        }
    </style>
</head>

<body>

    <!-- User Info outside the container -->
    <div class="user-info">
        <i class="fa-solid fa-circle-user"></i>
        <span>Logged in as <?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
        <a href="logout.php" style="text-decoration: none; padding-left: 10px;">
            <i class="fa fa-lock" style="font-size: 18px; color: #10346C;"></i>
            <span style="color: black;">Logout</span>
        </a>
    </div>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="sidebar">
                <div class="text-center">
                    <img src="images/dict_logo.png" alt="DICT Logo">
                </div>

                <ul class="nav flex-column mt-3">
                    <li class="nav-item active">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fa-solid fa-calendar-check"></i> Attendance
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="travelorder/travelorder.php">
                            <i class="fa-solid fa-plane-departure"></i> Travel Orders
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-4">
                <div class="container container-bordered">
                    <h2>Welcome, <?php echo $_SESSION['fullname']; ?>!</h2>
                    <p>You are now logged in.</p>
                </div>
            </main>
 
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
