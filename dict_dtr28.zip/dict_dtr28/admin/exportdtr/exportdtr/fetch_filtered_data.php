<?php
require '../connection.php'; // Adjust path as needed

$year = $_GET['year'] ?? '';
$month = $_GET['month'] ?? '';
$period = $_GET['period'] ?? '';
$designation = $_GET['designation'] ?? '';
$division = $_GET['division'] ?? '';

$query = "SELECT fname, username, designation, division FROM tbl_user WHERE 1";

if (!empty($year)) {
    $query .= " AND YEAR(date_approved) = '$year'";
}
if (!empty($month)) {
    $query .= " AND MONTHNAME(date_approved) = '$month'";
}
if (!empty($period)) {
    if ($period == "1st Half") {
        $query .= " AND DAY(date_approved) BETWEEN 1 AND 15";
    } elseif ($period == "2nd Half") {
        $query .= " AND DAY(date_approved) BETWEEN 16 AND 31";
    }
}
if (!empty($designation)) {
    $query .= " AND designation = '$designation'";
}
if (!empty($division)) {
    $query .= " AND division = '$division'";
}

$query .= " ORDER BY date_approved DESC";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['fname']}</td>
                <td>{$row['designation']}</td>
                <td>{$row['division']}</td>
                <td><a href='view_dtr.php?username={$row['username']}' class='btn btn-primary'>viewDTR</a></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4' class='text-center'>No records found</td></tr>";
}
?>
