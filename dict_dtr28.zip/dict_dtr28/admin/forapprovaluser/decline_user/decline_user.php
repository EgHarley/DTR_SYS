<?php
include '../../connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        
        // Delete user from tbl_registration
        $query = "DELETE FROM tbl_registration WHERE username = '$username'";
        if (mysqli_query($conn, $query)) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to delete user."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Username not provided."]);
    }
}
?>
