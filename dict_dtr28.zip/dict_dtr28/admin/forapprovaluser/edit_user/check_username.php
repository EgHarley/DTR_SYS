<?php
include '../../../connection.php';

if (isset($_GET['username'])) {
    $username = mysqli_real_escape_string($conn, $_GET['username']);
    
    $query = "SELECT username FROM tbl_user WHERE username = '$username' 
              UNION 
              SELECT username FROM tbl_registration WHERE username = '$username'";
    
    $result = mysqli_query($conn, $query);

    $response = ['exists' => mysqli_num_rows($result) > 0];
    echo json_encode($response);
}
?>
