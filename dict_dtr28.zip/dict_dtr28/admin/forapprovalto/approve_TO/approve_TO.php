<?php
include '../../connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['to_no'])) {
        $to_no = mysqli_real_escape_string($conn, $_POST['to_no']);
        
        // Corrected UPDATE query
        $query = "UPDATE tbl_travel_order SET status = 'Approved' WHERE to_no = '$to_no'";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update travel order."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "T.O. Number not provided."]);
    }
}
?>
