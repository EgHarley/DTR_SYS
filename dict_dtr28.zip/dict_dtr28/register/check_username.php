<?php
include '../include/connection.php'; // Adjust the path to your connection file

if (isset($_POST['username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Check if the username exists in either tbl_user or tbl_registration
    $query = "SELECT 1 FROM tbl_user WHERE username = '$username' 
              UNION 
              SELECT 1 FROM tbl_registration WHERE username = '$username'
              LIMIT 1";

    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo 'taken';  // Username is already taken
    } else {
        echo 'available';  // Username is available
    }
}
?>
