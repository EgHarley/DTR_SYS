<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include '../../connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Approved Users</title>
    <link rel="icon" type="image/x-icon" href="../../images/LOGO.ico">
    <link rel="stylesheet" href="../../sidebar/style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <!-- sweet alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
    }

    ul.nav-list {
        padding-left: 0rem;
    }

    .dropdown-links {
        display: none;
        /* Hide the links by default */
        list-style-type: none;
        padding-left: 20px;
    }

    /* Show dropdown on hover */
    .dropdown:hover .dropdown-links {
        display: block;
    }

    .dropdown-links li {
        margin: 5px 0;
    }

    .dropdown-links a {
        text-decoration: none;
        color: white;
    }

    .dropdown-links a:hover {
        color: #007bff;
        /* Change color on hover */
    }

    .icon {
        display: block;
        margin: 75px auto 0;
        width: 200px;
        height: auto;
    }

    #btn {
        height: 90px;
        /* Adjust height */
        /* line-height: 100px;  */
    }

    .user-info-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        margin-top: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
        color: #000;
    }

    .current-date {
        color: #000;
        font-size: 16px;
    }

    .card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-top: -55px;
    }

    .time-display {
        font-size: 72px;
        font-weight: bold;
        margin: 30px 0;
    }

    .time-buttons button {
        padding: 15px 30px;
        margin: 10px;
        font-size: 18px;
        border-radius: 8px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
    }

    .time-buttons button:disabled {
        background-color: #6c757d !important;
        /* Gray color */
        border-color: #6c757d !important;
        cursor: not-allowed;
        opacity: 0.65;
        /* Slight transparency */
    }

    table {
        width: 100%;
        margin-top: 40px;
        border-collapse: collapse;
    }

    table th,
    table td {
        padding: 15px;
        border: 1px solid #dee2e6;
        text-align: center;
    }

    table th {
        background-color: #f1f1f1;
        font-size: 18px;
    }

    table td {
        font-size: 16px;
    }

    /* back button */
    .back-btn {
        background-color: #10346C !important;
        border-color: #10346C !important;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    }

    .back-btn:hover {
        background-color: #0c2957 !important;
        border-color: #0c2957 !important;
    }

    /* swal */
    .custom-confirm-button {
        background-color: #10346C !important;
        color: white !important;
        width: 80px;
        margin-right: 10px !important;
    }

    .custom-cancel-button {
        background-color: #E60000 !important;
        color: white !important;
        margin-right: 10px !important;
        width: 80px;
    }
    .card .form-control{
        border-radius: 10px;
        border: 1px solid black;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    }
</style>

<body>
    <div class="sidebar">
        <div class="logo_details">
            <img src="../../images/dict_logo.png" alt="Logo" class="icon">
            <!-- <div class="logo_name">Try</div> -->
            <i class="bx bx-menu" id="btn"></i>
        </div><br><br>
        <ul class="nav-list">
            <li>
                <a href="../exportdtr/exportdtr.php" title="Export DTR">
                    <i class="fa-solid fa-calendar-check"></i>
                    <span class="link_name">Export DTR</span>
                </a>
            </li>
            <li>
                <a href="../approvedto/approvedto.php" title="Approved TOs">
                    <i class="fa-solid fa-file-circle-check"></i>
                    <span class="link_name">Approved TOs</span>
                </a>
            </li>
            <li>
                <a href="../approveduser/approveduser.php" title="Approved Users">
                    <i class="fa-solid fa-user-check"></i>
                    <span class="link_name">Approved Users</span>
                </a>
            </li>
            <li>
                <a href="../forapprovalto/forapprovalto.php" title="For Approval of TOs">
                    <i class="fa-solid fa-file-circle-exclamation"></i>
                    <span class="link_name">For Approval of TOs</span>
                </a>
            </li>
            <li>
                <a href="../forapprovaluser/approvaluser.php" title="For Approval of Users">
                    <i class="fa-solid fa-user-plus"></i>
                    <span class="link_name">For Approval of Users</span>
                </a>
            </li>
            <li>
                <a href="">
                    <i class="fa-solid fa-box-archive"></i>
                    <span class="link_name">Archive</span>
                </a>
            </li>
            <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
        </ul>
    </div>

    <section class="home-section">

        <?php include '../../include/header.php'; ?>

        <div class="user-info-container">
            <div class="user-info">
                <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C; margin-right: 3px;"></i>
                <span>Logged in as
                    <?php
                    echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
                    ?>
                </span>
                <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; padding-left: 10px;">
                    <i class="fa fa-lock" style="font-size: 18px; color: #10346C;"></i>
                    <span style="color: black;">Logout</span>
                </a>
            </div>

            <div class="current-date d-flex align-items-center">
                <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
                <span id="current-date"></span>
            </div>
        </div>

        <br><br>

        <!-- main dash contents -->
        <main class="px-3 py-2" style="background-color: #e6e4e4;">
            <div class="container-fluid">
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-file-circle-exclamation me-2 fs-4"></i>
                            <span class="fw-bold fs-4">Edit Travel Order Details</span>
                        </div>
                        <a href="forapprovalto.php" class="btn btn-primary back-btn">Back</a>
                    </div>

                    <div class="card-body d-flex justify-content-center align-items-center"
                        style="max-height: 505px; overflow-y: auto; border: 1px solid #ccc;">
                        <?php
                        if (isset($_GET['to_no'])) {
                            $to_no = $_GET['to_no'];

                            $stmt = $conn->prepare("SELECT * FROM tbl_travel_order INNER JOIN tbl_user ON tbl_travel_order.username = tbl_user.username WHERE tbl_travel_order.to_no = ?");
                            $stmt->bind_param("s", $to_no);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($row = $result->fetch_assoc()) {
                                ?>
                                <div class="card" style="width: 400px; margin-top: 10px; background-color: #D9D9D6; ">
                                    <div class="card-body">
                                        <form id="toForm">
                                            <div class="row">
                                            <input type="text" name="orig_to_no" class="form-control" hidden
                                            value="<?= htmlspecialchars($row['to_no']) ?>">
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>T.O. Number:</strong></label>
                                                    <input type="text" id="toNo" name="to_no" class="form-control"
                                                        value="<?= htmlspecialchars($row['to_no']) ?>">
                                                </div>
                                                <script>
                                                    document.getElementById('toNo').addEventListener('input', function (e) {
                                                        let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); // Allow only letters and numbers, convert to uppercase
                                                        let formattedValue = '';

                                                        if (value.length > 2) formattedValue += value.substring(0, 2) + '-';
                                                        else formattedValue = value;

                                                        if (value.length > 4) formattedValue += value.substring(2, 4) + '-';
                                                        else if (value.length > 2) formattedValue += value.substring(2);

                                                        if (value.length > 4) formattedValue += value.substring(4, 8);

                                                        e.target.value = formattedValue;
                                                    });
                                                </script>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Name:</strong></label>
                                                    <input type="text" name="fname" class="form-control"
                                                        value="<?= htmlspecialchars($row['fname']) ?>" readonly>
                                                </div>

                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Dates:</strong></label>
                                                    <input type="text" name="dates" class="form-control" id="dates"
                                                        value="<?= htmlspecialchars($row['dates']) ?>">
                                                    <script>
                                                        $(function() {
                                                    $("#dates").daterangepicker({
                                                        autoUpdateInput: false,
                                                        locale: {
                                                            cancelLabel: 'Clear',
                                                            format: 'MM/DD/YYYY'
                                                        }
                                                    });

                                                    $("#dates").on('apply.daterangepicker', function(ev, picker) {
                                                        $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
                                                    });

                                                    $("#dates").on('cancel.daterangepicker', function(ev, picker) {
                                                        $(this).val('');
                                                    });
                                                });
                                                    </script>
                                                    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
                                                    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
                                                    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
                                                </div>

                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Purpose:</strong></label>
                                                    <input type="text" name="purpose" class="form-control"
                                                        value="<?= htmlspecialchars($row['purpose']) ?>">
                                                </div>
                                            </div>

                                            <!-- Buttons -->
                                            <div class="mt-4 text-center">
                                                <button type="button" class="btn save-btn"
                                                style="background-color: #10346C; color: white; border: none; border-radius: 8px;
                        cursor: pointer; width: 100%; height: 35px; font-size: 0.9em; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);">Save</button>
                                            </div>
                                        </form>

                                        <?php
                            } else {
                                echo "<p class='text-danger'>No user found.</p>";
                            }
                            $stmt->close();
                        } else {
                            echo "<p class='text-danger'>Invalid request.</p>";
                        }
                        ?>
                            </div>
                        </div>
                    </div>
    </section>

    <!-- save btn -->
    <script>
        $(document).ready(function () {
            $(".save-btn").on("click", function () {

                Swal.fire({
                    title: "Are you sure you want to save the changes?",
                    icon: "question",
                    showCancelButton: true,
                    confirmButtonColor: "#10346C",
                    cancelButtonColor: "#E60000",
                    cancelButtonText: "No",
                    confirmButtonText: "Yes"
                }).then((result) => {
                    if (result.isConfirmed) {
                        let formData = $("#toForm").serialize();

                        $.ajax({
                            type: "POST",
                            url: "updateTO_process.php",
                            data: formData,
                            success: function (response) {
                                Swal.fire({
                                    title: "Successfully Updated!",
                                    icon: "success",
                                    timer: 1500,
                                    showConfirmButton: false
                                });

                                setTimeout(() => {
                                    window.location.href = "forapprovalto.php";
                                }, 1500);
                            },
                            error: function () {
                                Swal.fire({
                                    title: "Error!",
                                    text: "Something went wrong.",
                                    icon: "error",
                                    confirmButtonText: "OK"
                                });
                            }
                        });
                    }
                });
            });
        });
    </script>




    <!-- date -->
    <script>
        function updateClock() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
        }

        setInterval(updateClock, 1000);

        // Call it immediately to display the time without delay
        updateClock();
    </script>

</body>

</html>