<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
include '../../connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Archive TO</title>
    <link rel="icon" type="image/x-icon" href="../../images/LOGO.ico">
    <link rel="stylesheet" href="../../sidebar/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<style>
    body {
        font-family: Arial, sans-serif;
    }

    ul.nav-list {
        padding-left: 0;
    }

    .dropdown-links {
        display: none;
        list-style-type: none;
        padding-left: 20px;
    }

    .dropdown-links {
    display: none;
    }

    .dropdown.active .dropdown-links {
        display: block;
    }


    .dropdown-links li {
        margin: 5px 0;
    }

    .dropdown-links a {
    text-decoration: none;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px;
    border-radius: 5px;
    width: 30px;
    height: 30px;
    transition: background-color 0.3s ease;
    }

    .dropdown-links a:hover {
        color: #007bff;
    }

    .icon {
        display: block;
        margin: 75px auto 0;
        width: 200px;
        height: auto;
    }

    #btn {
        height: 90px;
    }

    .user-info-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        margin-top: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
        color: #000;
    }

    .current-date {
        color: #000;
        font-size: 16px;
    }

    .card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-top: -55px;
    }

    table {
        width: 100%;
        margin-top: 40px;
        border-collapse: collapse;
        border: 1px solid #ccc;
    }

    table th,
    table td {
        padding: 15px;
        border: 1px solid #ccc;
        text-align: center;
    }

    table th {
        background-color: #10346C;
        color: white;
        font-size: 18px;
    }

    table td {
        font-size: 16px;
        background-color: #DEDEDE;
        color: black;
    }

    .dropdown-links a.active {
    background-color: #10346C;
    color: #fff !important;
    }

</style>

<body>
            <div class="sidebar">
                <div class="logo_details">
                    <img src="../../images/dict_logo.png" alt="Logo" class="icon">
                    <i class="bx bx-menu" id="btn"></i>
                </div><br><br>
                <ul class="nav-list">
        <li>
            <a href="../exportdtr/exportdtr.php" title="Export DTR">
            <i class="fa-solid fa-calendar-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../approvedto/approvedto.php" title="Approved TOs">
            <i class="fa-solid fa-file-circle-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../approveduser/approveduser.php" title="Approved Users">
            <i class="fa-solid fa-user-check fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../forapprovalto/forapprovalto.php" title="For Approval of TOs">
            <i class="fa-solid fa-file-circle-exclamation fa-xl"></i>
            </a>
        </li>
        <li>
            <a href="../forapprovaluser/approvaluser.php" title="For Approval of Users">
            <i class="fa-solid fa-user-plus fa-xl"></i>
            </a>
        </li>

        <!-- Archive Dropdown Only Icons -->
        <li class="dropdown">
            <a href="#" title="Archive"><i class="fa-solid fa-box-archive fa-xl"></i></a>
            <ul class="dropdown-links">
            <li><a href="archive_to.php" title="TO Archive"><i class="fa-solid fa-file"></i></a></li>
            <li><a href="archive_dtr.php" title="DTR Archive"><i class="fa-solid fa-calendar"></i></a></li>
            <li><a href="archive_users.php" title="Users Archive"><i class="fa-solid fa-users"></i></a></li>
            </ul>
        </li>
        </ul>
    </div>

    <section class="home-section">
        <?php include '../../include/header.php'; ?>

        <div class="user-info-container">
            <div class="user-info">
                <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C;"></i>
                <span>Logged in as <?php echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']); ?></span>
                <a href="../logout_admin.php" class="ms-3" style="text-decoration: none;"><i class="fa fa-lock"></i> Logout</a>
            </div>
            <div class="current-date d-flex align-items-center">
                <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
                <span id="current-date"></span>
            </div>
        </div>

        <br><br>

        <main class="px-3 py-2" style="background-color: #e6e4e4;">
            <div class="container-fluid">
                <div class="card mb-3">
                    <div class="card-header d-flex align-items-center">
                        <i class="fa-solid fa-box-archive me-2 fs-4"></i>
                        <span class="fw-bold fs-4">Archive Section</span>
                    </div>
                    <div class="card-body" style="max-height: 505px; overflow-y: auto; border: 1px solid #ccc;">

                        <?php
                        if (isset($_GET['archive'])) {
                            $archiveType = $_GET['archive'];

                            // Adjust your queries based on real archive tables
                            if ($archiveType === 'to') {
                                echo "<h5>Archived TO Records</h5>";
                                $query = "SELECT * FROM tbl_to_archive ORDER BY archived_date DESC";
                            } elseif ($archiveType === 'dtr') {
                                echo "<h5>Archived DTR Records</h5>";
                                $query = "SELECT * FROM tbl_dtr_archive ORDER BY archived_date DESC";
                            } elseif ($archiveType === 'users') {
                                echo "<h5>Archived Users</h5>";
                                $query = "SELECT * FROM tbl_archived_users ORDER BY archived_date DESC";
                            } else {
                                echo "<p>Invalid archive selection.</p>";
                                exit();
                            }

                            $result = mysqli_query($conn, $query);
                            if (mysqli_num_rows($result) > 0) {
                                echo "<div class='table-responsive'><table class='table table-hover' style='margin-top: 5px'>";
                                echo "<thead><tr>";
                                foreach (array_keys(mysqli_fetch_assoc($result)) as $col) {
                                    echo "<th>" . htmlspecialchars($col) . "</th>";
                                }
                                echo "</tr></thead><tbody>";
                                mysqli_data_seek($result, 0);
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    foreach ($row as $value) {
                                        echo "<td>" . htmlspecialchars($value) . "</td>";
                                    }
                                    echo "</tr>";
                                }
                                echo "</tbody></table></div>";
                            } else {
                                echo "<p>No archived records found.</p>";
                            }
                        } else {
                            echo "<p>Select an archive type from the sidebar (TO, DTR, Users).</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </main>
    </section>

    <script>
        function updateClock() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
        }
        setInterval(updateClock, 1000);
        updateClock();
    </script>

    <script>
        $(document).ready(function () {
        // Toggle archive dropdown on Archive icon click
        $('.dropdown > a').click(function (e) {
            e.preventDefault();
            $('.dropdown').toggleClass('active');
        });

        // Auto open archive if inside archive page (optional based on URL params)
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('archive')) {
            $('.dropdown').addClass('active');
        }

        // Clicking other menu items (EXCEPT archive & its children) closes archive
        $('.nav-list li > a').not('.dropdown > a, .dropdown-links a').click(function () {
            $('.dropdown').removeClass('active');
        });

        // Archive dropdown links should NOT close the dropdown when clicked
        $('.dropdown-links a').click(function (e) {
            // Let the default behavior continue (navigation)
            $('.dropdown').addClass('active'); // Ensures it stays open
        });
    });

    </script>


    <script src="../../sidebar/sidebar.js"></script>
</body>
</html>
