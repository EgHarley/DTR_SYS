<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include '../../../connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>For Approval of Users</title>
    <link rel="icon" type="image/x-icon" href="../../../images/LOGO.ico">
    <link rel="stylesheet" href="../../../sidebar/style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <!-- sweet alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
    }

    ul.nav-list {
        padding-left: 0rem;
    }

    .dropdown-links {
        display: none;
        /* Hide the links by default */
        list-style-type: none;
        padding-left: 20px;
    }

    /* Show dropdown on hover */
    .dropdown:hover .dropdown-links {
        display: block;
    }

    .dropdown-links li {
        margin: 5px 0;
    }

    .dropdown-links a {
        text-decoration: none;
        color: white;
    }

    .dropdown-links a:hover {
        color: #007bff;
        /* Change color on hover */
    }

    .icon {
        display: block;
        margin: 75px auto 0;
        width: 200px;
        height: auto;
    }

    #btn {
        height: 90px;
        /* Adjust height */
        /* line-height: 100px;  */
    }

    .user-info-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        margin-top: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
        color: #000;
    }

    .current-date {
        color: #000;
        font-size: 16px;
    }

    .card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-top: -55px;
    }

    .time-display {
        font-size: 72px;
        font-weight: bold;
        margin: 30px 0;
    }

    .time-buttons button {
        padding: 15px 30px;
        margin: 10px;
        font-size: 18px;
        border-radius: 8px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
    }

    .time-buttons button:disabled {
        background-color: #6c757d !important;
        /* Gray color */
        border-color: #6c757d !important;
        cursor: not-allowed;
        opacity: 0.65;
        /* Slight transparency */
    }

    table {
        width: 100%;
        margin-top: 40px;
        border-collapse: collapse;
    }

    table th,
    table td {
        padding: 15px;
        border: 1px solid #dee2e6;
        text-align: center;
    }

    table th {
        background-color: #f1f1f1;
        font-size: 18px;
    }

    table td {
        font-size: 16px;
    }

    /* back button */
    .back-btn {
        background-color: #10346C !important;
        border-color: #10346C !important;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    }

    .back-btn:hover {
        background-color: #0c2957 !important;
        border-color: #0c2957 !important;
    }

    /* swal */
    .custom-confirm-button {
        background-color: #10346C !important;
        color: white !important;
        width: 80px;
        margin-right: 10px !important;
    }

    .custom-cancel-button {
        background-color: #E60000 !important;
        color: white !important;
        margin-right: 10px !important;
        width: 80px;
    }
    .card .form-control{
        border-radius: 10px;
        border: 1px solid black;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-left: -95px;
        height: 32px;
        width: 300px;
    }
</style>

<body>
    <div class="sidebar">
        <div class="logo_details">
            <img src="../../../images/dict_logo.png" alt="Logo" class="icon">
            <!-- <div class="logo_name">Try</div> -->
            <i class="bx bx-menu" id="btn"></i>
        </div><br><br>
        <ul class="nav-list">
            <li>
                <a href="../../exportdtr/exportdtr.php" title="Export DTR">
                    <i class="fa-solid fa-calendar-check"></i>
                    <span class="link_name">Export DTR</span>
                </a>
            </li>
            <li>
                <a href="../../approvedto/approvedto.php" title="Approved TOs">
                    <i class="fa-solid fa-file-circle-check"></i>
                    <span class="link_name">Approved TOs</span>
                </a>
            </li>
            <li>
                <a href="../../approveduser/approveduser.php" title="Approved Users">
                    <i class="fa-solid fa-user-check"></i>
                    <span class="link_name">Approved Users</span>
                </a>
            </li>
            <li>
                <a href="../../forapprovalto/forapprovalto.php" title="For Approval of TOs">
                    <i class="fa-solid fa-file-circle-exclamation"></i>
                    <span class="link_name">For Approval of TOs</span>
                </a>
            </li>
            <li>
                <a href="../approvaluser.php" title="For Approval of Users">
                    <i class="fa-solid  fa-user-plus"></i>
                    <span class="link_name">For Approval of Users</span>
                </a>
            </li>
            <li>
                <a href="">
                    <i class="fa-solid fa-box-archive"></i>
                    <span class="link_name">Archive</span>
                </a>
            </li>
            <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
        </ul>
    </div>

    <section class="home-section">

        <?php include '../../../include/header.php'; ?>

        <div class="user-info-container">
            <div class="user-info">
                <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C; margin-right: 3px;"></i>
                <span>Logged in as
                    <?php
                    echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
                    ?>
                </span>
                <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; padding-left: 10px;">
                    <i class="fa fa-lock" style="font-size: 18px; color: #10346C;"></i>
                    <span style="color: black;">Logout</span>
                </a>
            </div>

            <div class="current-date d-flex align-items-center">
                <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
                <span id="current-date"></span>
            </div>
        </div>

        <br><br>

        <!-- main dash contents -->
        <main class="px-3 py-2" style="background-color: #e6e4e4;">
            <div class="container-fluid">
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-calendar-check me-2 fs-4"></i>
                            <span class="fw-bold fs-4">Edit User Details</span>
                        </div>
                        <a href="../view_user.php<?= isset($_GET['username']) ? '?username=' . urlencode($_GET['username']) : '' ?>"
                            class="btn btn-primary back-btn">Back</a>
                    </div>

                    <div class="card-body d-flex justify-content-center align-items-center"
                        style="max-height: 505px; overflow-y: auto; border: 1px solid #ccc;">
                        <?php
                        if (!isset($_GET['username']) || empty($_GET['username'])) {
                            echo "<p class='text-danger'>Invalid request.</p>";
                        } else {
                            include '../../../connection.php';

                            $username = mysqli_real_escape_string($conn, $_GET['username']);
                            $query = "SELECT * FROM tbl_registration WHERE username = '$username'";
                            $result = mysqli_query($conn, $query);

                            if ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <div class="card" style="width: 500px; margin-top: 10px; background-color: #D9D9D6; padding: 20px;">
                                    <div class="card-body">
                                        <form id="userForm">
                                            <div class="row">
                                                <!-- Left Column -->
                                                <div class="col-md-6">
                                                    <div class="mb-2">
                                                    <input type="text" class="form-control" id="uname" name="uname"
                                                    value="<?= htmlspecialchars($row['username']) ?>" hidden>
                                                        <label class="form-label"><strong>Username:</strong></label>
                                                    </div><br>

                                                    <div class="mb-2">
                                                        <label class="form-label"><strong>Full Name:</strong></label>
                                                    </div><br>

                                                    <div class="mb-2">
                                                        <label class="form-label"><strong>Division:</strong></label>
                                                    </div><br>

                                                    <div class="mb-2">
                                                    <label class="form-label"><strong>Designation:</strong></label>
                                                    </div><br>

                                                    <div class="mb-2">
                                                    <label class="form-label"><strong>Position:</strong></label>
                                                    </div>
                                                    </div>
                                                
                                            <!-- Right Column -->
                                             <div class="col-md-6">
                                                <div class="mb-2">
                                                    <input type="text" class="form-control" id="username" name="username"
                                                    value="<?= htmlspecialchars($row['username']) ?>">
                                                    <small id="usernameFeedback" class="username-feedback"></small>
                                                    </div><br>

                                                    <div class="mb-2">
                                                        <input type="text" class="form-control" name="fname" id="fname"
                                                        value="<?= htmlspecialchars($row['fname']) ?>">
                                                    </div><br>

                                                    <div class="mb-2">
                                                    <select class="form-control" name="division">
                                                    <option value="AFD" <?= ($row['division'] == 'AFD') ? 'selected' : '' ?>>AFD</option>
                                                    <option value="TOD" <?= ($row['division'] == 'TOD') ? 'selected' : '' ?>>TOD</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="mb-2">
                                                    <select class="form-control" name="designation">
                                                    <option value="La Union" <?= ($row['designation'] == 'La Union') ? 'selected' : '' ?>>La Union</option>
                                                    <option value="Pangasinan" <?= ($row['designation'] == 'Pangasinan') ? 'selected' : '' ?>>Pangasinan</option>
                                                    <option value="Ilocos Norte" <?= ($row['designation'] == 'Ilocos Norte') ? 'selected' : '' ?>>Ilocos Norte</option>
                                                    <option value="Ilocos Sur" <?= ($row['designation'] == 'Ilocos Sur') ? 'selected' : '' ?>>Ilocos Sur</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="mb-2">
                                                    <input type="text" class="form-control" name="position" id="position"
                                                    value="<?= htmlspecialchars($row['position']) ?>">
                                                    </div>
                                                </div> 
                                            </div>
                                            <!-- Buttons -->
                                            <div class="mt-4 text-center">
                                                <button type="button" class="btn save-btn"
                                                style="background-color: #10346C; color: white; border: none; border-radius: 8px;
                        cursor: pointer; width: 100%; height: 35px; font-size: 0.9em; box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php
                            } else {
                                echo "<p class='text-danger'>No user found.</p>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </main>

    </section>

    <!-- Scripts -->
    <script src="../../../sidebar/sidebar.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- save btn -->
    <script>
        $(document).ready(function () {
            $(".save-btn").on("click", function () {
                let feedback = $("#usernameFeedback").text().trim();

                // Prevent saving if username already exists
                if (feedback === "Username already exists.") {
                    Swal.fire({
                        title: "Error!",
                        text: "Username is already taken. Please choose another one.",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                    return; // Stop execution
                }

                Swal.fire({
                    title: "Are you sure you want to save the changes?",
                    icon: "question",
                    showCancelButton: true,
                    confirmButtonColor: "#10346C",
                    cancelButtonColor: "#E60000",
                    cancelButtonText: "No",
                    confirmButtonText: "Yes"
                }).then((result) => {
                    if (result.isConfirmed) {
                        let formData = $("#userForm").serialize();

                        $.ajax({
                            type: "POST",
                            url: "update_user.php",
                            data: formData,
                            success: function (response) {
                                Swal.fire({
                                    title: "Successfully Updated!",
                                    icon: "success",
                                    timer: 1500,
                                    showConfirmButton: false
                                });

                                setTimeout(() => {
                                    window.location.href = "../approvaluser.php";
                                }, 1500);
                            },
                            error: function () {
                                Swal.fire({
                                    title: "Error!",
                                    text: "Something went wrong.",
                                    icon: "error",
                                    confirmButtonText: "OK"
                                });
                            }
                        });
                    }
                });
            });
        });
    </script>

    <!-- username validation -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const usernameInput = document.getElementById("username");
            const feedback = document.getElementById("usernameFeedback");
            const originalUsername = document.getElementById("uname").value; // Get the original username

            usernameInput.addEventListener("input", function () {
                let username = usernameInput.value.trim();

                if (username === "") {
                    feedback.textContent = "";
                    feedback.style.color = ""; // Reset color
                    return;
                }

                // If the username is the same as the original, clear feedback
                if (username === originalUsername) {
                    feedback.textContent = "";
                    return;
                }

                fetch("check_username.php?username=" + encodeURIComponent(username))
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            feedback.textContent = "Username already exists.";
                            feedback.style.color = "red";
                        } else {
                            feedback.textContent = "Username is available.";
                            feedback.style.color = "green"; // Ensure green color is applied
                        }
                    })
                    .catch(error => console.error("Error:", error));
            });
        });
    </script>

    <!-- Logout Script -->
    <script>
        document.getElementById("logoutLink").addEventListener("click", function (event) {
            event.preventDefault(); // Prevent immediate navigation

            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: "custom-confirm-button btn",
                    cancelButton: "custom-cancel-button btn"
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: "Are you sure you want <br> to log out?",
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: false
            }).then((result) => {
                if (result.isConfirmed) {
                    swalWithBootstrapButtons.fire({
                        title: "Successfully logged out!",
                        icon: "success",
                        showConfirmButton: false, // Remove "OK" button
                        timer: 2000, // Auto-close after 2 seconds
                        timerProgressBar: true // Show progress bar
                    });

                    setTimeout(() => {
                        window.location.href = "../../logout_admin.php"; // Redirect after 2 seconds
                    }, 1090);
                }
            });
        });
    </script>

    <!-- date -->
    <script>
        function updateClock() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
        }

        setInterval(updateClock, 1000);

        // Call it immediately to display the time without delay
        updateClock();
    </script>

</body>

</html>