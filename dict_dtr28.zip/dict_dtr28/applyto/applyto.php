<?php
include '../include/header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Order Application</title>
    <link rel="icon" type="image/x-icon" href="images/LOGO.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(to bottom, #ffffff 0%, #ffffff 68%, #10346C 100%);
            background-size: cover;
            background-attachment: fixed;
        }

        /* Prevent scrolling and ensure full height */
        html,
        body {
            height: 100%;
            margin: 0;
            overflow: auto;
        }

        header,
        .header-container {
            margin: 0;
            padding: 0;
            width: 100vw;
        }

        .container {
            background-color: #D9D9D6 !important;
            border-radius: 10px;
            width: 40%;
            margin-top: 50px;
            max-width: 1000px;
            border-color: rgb(0, 0, 0);
            padding: 20px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        form {
            padding: 20px;
            margin-top: -20px;
        }

        .container h2 {
            text-align: center;
            margin-top: 10px;
        }

        label {
            font-size: 0.8em;
        }

        .form-control {
            border: 1px solid black;
            border-radius: 10px;
            font-size: 0.8em;
            height: 35px;
            margin-bottom: 10px;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        .cancel:hover {
            background-color: #10346C !important;
            border-color: #10346C !important;
            color: rgb(255, 255, 255);
        }

        .cancel {
            background: white;
            color: black;
            border: 2px;
            border-radius: 8px;
            cursor: pointer;
            width: 80px;
            height: 35px;
            font-size: 0.9em;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
            width: 100%;
            margin-top: 5px;
        }

        .save {
            background: #10346C;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            height: 35px;
            font-size: 0.9em;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>

<body>

    <div class="container p-4 bg-white shadow rounded" style="max-width: 400px;">
        <h4 class="text-center">Travel Order Application</h4>
        <hr>
        <form action="applyto_process.php" id="ApplyTO" method="POST">
            <div class="mb-3">
                <label class="form-label">TO No. <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="toNo" id="toNo" placeholder="XX-XX-XXXX" maxlength="11"
                    required>
            </div>

            <script>
                document.getElementById('toNo').addEventListener('input', function (e) {
                    let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); // Allow only letters and numbers, convert to uppercase
                    let formattedValue = '';

                    if (value.length > 2) formattedValue += value.substring(0, 2) + '-';
                    else formattedValue = value;

                    if (value.length > 4) formattedValue += value.substring(2, 4) + '-';
                    else if (value.length > 2) formattedValue += value.substring(2);

                    if (value.length > 4) formattedValue += value.substring(4, 8);

                    e.target.value = formattedValue;
                });
            </script>


            <div class="mb-3">
                <label class="form-label">Username <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="username" id="username" oninput="checkUsername()"
                    required>
                <span id="check_username" class="text-muted small"></span>
            </div>

            <script>
                function checkUsername() {
                    let username = $("#username").val().trim();
                    if (username === "") {
                        $("#check_username").html("");
                        return;
                    }

                    $.ajax({
                        url: "checkUser.php",
                        type: "POST",
                        data: { username: username },
                        success: function (data) {
                            $("#check_username").html(data);
                        },
                        error: function () {
                            $("#check_username").html("<span style='color:red'>Error checking username.</span>");
                        }
                    });
                }
            </script>

            <div class="mb-3">
                <label class="form-label">Dates</label>
                <input type="text" class="form-control" name="dates" id="dates" required>
                <script>
                    $(function() {
                        $("#dates").daterangepicker({
                            autoUpdateInput: false,
                            locale: {
                                cancelLabel: 'Clear',
                                format: 'MM/DD/YYYY'
                            }
                        });

                        $("#dates").on('apply.daterangepicker', function(ev, picker) {
                            $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
                        });

                        $("#dates").on('cancel.daterangepicker', function(ev, picker) {
                            $(this).val('');
                        });
                    });
                </script>
                <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
                <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
            </div>

            <div class="mb-3">
                <label class="form-label">Purpose</label>
                <input type="text" class="form-control" name="purpose" id="purpose" required>
            </div>

            <br>
            <button class="save" type="submit">Save</button>
            <button class="cancel" type="button" onclick="confirmBackToHome()">Back to Home</button>
        </form>
    </div>



</body>

</html>

<?php include('script.php'); ?>