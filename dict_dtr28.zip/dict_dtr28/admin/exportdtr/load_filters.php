<?php
require '../connection.php'; // Adjust path as needed

header('Content-Type: application/json');

$response = [
    'years' => [],
    'months' => [],
    'designations' => [],
    'divisions' => [],
    'default' => [
        'year' => '',
        'month' => '',
        'period' => '',
        'designation' => 'LA UNION',
        'division' => 'TOD'
    ]
];

// Fetch latest year
$yearQuery = "SELECT DISTINCT YEAR(date_approved) AS year FROM tbl_user ORDER BY year DESC";
$yearResult = $conn->query($yearQuery);
while ($row = $yearResult->fetch_assoc()) {
    $response['years'][] = $row['year'];
}
$response['default']['year'] = $response['years'][0] ?? ''; // Set latest year

// Fetch latest month
$monthQuery = "SELECT DISTINCT MONTHNAME(date_approved) AS month FROM tbl_user ORDER BY MONTH(date_approved) DESC";
$monthResult = $conn->query($monthQuery);
while ($row = $monthResult->fetch_assoc()) {
    $response['months'][] = $row['month'];
}
$response['default']['month'] = $response['months'][0] ?? ''; // Set latest month

// Fetch latest date to determine period
$latestDateQuery = "SELECT date_approved FROM tbl_user ORDER BY date_approved DESC LIMIT 1";
$latestDateResult = $conn->query($latestDateQuery);
if ($row = $latestDateResult->fetch_assoc()) {
    $latestDay = date('j', strtotime($row['date_approved']));
    $response['default']['period'] = ($latestDay <= 15) ? '1st Half' : '2nd Half';
}

// Fetch unique designations
$designationQuery = "SELECT DISTINCT designation FROM tbl_user ORDER BY designation";
$designationResult = $conn->query($designationQuery);
while ($row = $designationResult->fetch_assoc()) {
    $response['designations'][] = $row['designation'];
}

// Fetch unique divisions
$divisionQuery = "SELECT DISTINCT division FROM tbl_user ORDER BY division";
$divisionResult = $conn->query($divisionQuery);
while ($row = $divisionResult->fetch_assoc()) {
    $response['divisions'][] = $row['division'];
}

echo json_encode($response);
?>
