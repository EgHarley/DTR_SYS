<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// include 'include/header.php'
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Travel Order</title>
    <link rel="icon" type="image/x-icon" href="../images/LOGO.ico">
    <link rel="stylesheet" href="../sidebar/style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <!-- sweet alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
    }

    ul.nav-list {
        padding-left: 0rem;
    }

    .dropdown-links {
        display: none;
        /* Hide the links by default */
        list-style-type: none;
        padding-left: 20px;
    }

    /* Show dropdown on hover */
    .dropdown:hover .dropdown-links {
        display: block;
    }

    .dropdown-links li {
        margin: 5px 0;
    }

    .dropdown-links a {
        text-decoration: none;
        color: white;
    }

    .dropdown-links a:hover {
        color: #007bff;
        /* Change color on hover */
    }

    .icon {
        display: block;
        margin: 75px auto 0;
        width: 200px;
        height: auto;
    }

    #btn {
        height: 90px;
        /* Adjust height */
        /* line-height: 100px;  */
    }

    .user-info-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        margin-top: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
        color: #000;
    }

    .current-date {
        color: #000;
        font-size: 16px;
    }

    .card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
        margin-top: -55px;
    }

    .time-display {
        font-size: 72px;
        font-weight: bold;
        margin: 30px 0;
    }

    .time-buttons button {
        padding: 15px 30px;
        margin: 10px;
        font-size: 18px;
        border-radius: 8px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
    }

    .time-buttons button:disabled {
        background-color: #6c757d !important;
        /* Gray color */
        border-color: #6c757d !important;
        cursor: not-allowed;
        opacity: 0.65;
        /* Slight transparency */
    }

    table {
        width: 100%;
        margin-top: 40px;
        border-collapse: collapse;
    }

    table th,
    table td {
        padding: 15px;
        border: 1px solid #dee2e6;
        text-align: center;
    }

    table th {
        background-color: #f1f1f1;
        font-size: 18px;
    }

    table td {
        font-size: 16px;
    }

    /* back button */
    .bck-btn {
        background-color: #10346C !important;
        border-color: #10346C !important;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    }

    .bck-btn:hover {
        background-color: #0c2957 !important;
        border-color: #0c2957 !important;
    }

    /* swal */
    .custom-confirm-button {
        background-color: #10346C !important;
        color: white !important;
        width: 80px;
        margin-right: 10px !important;
    }

    .custom-cancel-button {
        background-color: #E60000 !important;
        color: white !important;
        margin-right: 10px !important;
        width: 80px;
    }

    .save {
        background: #10346C;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        width: 100%;
        height: 35px;
        font-size: 0.9em;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
    }
</style>

<body>
    <div class="sidebar">
        <div class="logo_details">
            <img src="../images/dict_logo.png" alt="Logo" class="icon">
            <!-- <div class="logo_name">Try</div> -->
            <i class="bx bx-menu" id="btn"></i>
        </div><br><br>
        <ul class="nav-list">
            <li>
                <a href="../dashboard.php">
                    <i class="fa-solid fa-calendar-check"></i>
                    <span class="link_name">Attendance</span>
                </a>
            </li>
            <li>
                <a href="travelorder.php">
                    <i class="fa-solid fa-file-circle-plus"></i>
                    <span class="link_name">Travel Orders</span>
                </a>
            </li>
            <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
        </ul>
    </div>

    <section class="home-section">

        <?php include '../include/header.php'; ?>

        <div class="user-info-container">
            <div class="user-info">
                <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C; margin-right: 3px;"></i>
                <span>Logged in as
                    <?php
                    echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
                    ?>
                </span>
                <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; padding-left: 10px;">
                    <i class="fa fa-lock" style="font-size: 18px; color: #10346C;"></i>
                    <span style="color: black;">Logout</span>
                </a>
            </div>

            <div class="current-date d-flex align-items-center">
                <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
                <span id="current-date"></span>
            </div>
        </div>

        <br><br>

        <!-- main dash contents -->
        <main class="px-3 py-2" style="background-color: #e6e4e4;">
            <div class="container-fluid">
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-file-circle-plus me-2 fs-4"></i>
                            <span class="fw-bold fs-4"> Add Travel Order</span>
                        </div>
                        <a href="travelorder.php" class="btn btn-primary bck-btn">Back</a>
                    </div>

                    <div class="container p-4 bg-white shadow rounded" style="max-width: 400px;">
                        <h4 class="text-center">Travel Order Application</h4>
                        <hr>
                        <form action="addto_process.php" id="addTO" method="POST">
                            <div class="mb-3">
                                <label class="form-label">TO No. <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="toNo" id="toNo" placeholder="XX-XX-XXXX"
                                    maxlength="11" required>
                            </div>

                            <script>
                                document.getElementById('toNo').addEventListener('input', function (e) {
                                    let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); // Allow only letters and numbers, convert to uppercase
                                    let formattedValue = '';

                                    if (value.length > 2) formattedValue += value.substring(0, 2) + '-';
                                    else formattedValue = value;

                                    if (value.length > 4) formattedValue += value.substring(2, 4) + '-';
                                    else if (value.length > 2) formattedValue += value.substring(2);

                                    if (value.length > 4) formattedValue += value.substring(4, 8);

                                    e.target.value = formattedValue;
                                });
                            </script>
                            <input type="text" class="form-control" name="username" id="username"
                                value="<?php echo htmlspecialchars($_SESSION['username']); ?>" hidden>


                            <div class="mb-3">
                                <label class="form-label">Dates</label>
                                <input type="text" class="form-control" name="dates" id="dates" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Purpose</label>
                                <input type="text" class="form-control" name="purpose" id="purpose" required>
                            </div>

                            <br>
                            <button class="save" type="submit">Save</button>
                        </form>
                    </div>
                    <br>
                </div>
            </div>
        </main>

    </section>

    <!-- Scripts -->
    <script src="../sidebar/sidebar.js"></script>


    <!-- Logout Script -->
    <script>
        document.getElementById("logoutLink").addEventListener("click", function (event) {
            event.preventDefault(); // Prevent immediate navigation

            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: "custom-confirm-button btn",
                    cancelButton: "custom-cancel-button btn"
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: "Are you sure you want <br> to log out?",
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: false
            }).then((result) => {
                if (result.isConfirmed) {
                    swalWithBootstrapButtons.fire({
                        title: "Successfully logged out!",
                        icon: "success",
                        showConfirmButton: false, // Remove "OK" button
                        timer: 2000, // Auto-close after 2 seconds
                        timerProgressBar: true // Show progress bar
                    });

                    setTimeout(() => {
                        window.location.href = "../logout/logout.php"; // Redirect after 2 seconds
                    }, 1090);
                }
            });
        });
    </script>

<script>
    $(document).ready(function () {
        $("#addTO").submit(function (event) {
            event.preventDefault(); // Prevent default form submission

            Swal.fire({
                title: "Are you sure you want to add this travel order?",
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: false,
                customClass: {
                    confirmButton: "custom-confirm-button btn",
                    cancelButton: "custom-cancel-button btn"
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    let formData = $(this).serialize();

                    $.ajax({
                        url: "addto_process.php", // Correct URL
                        type: "POST", // Use POST method
                        data: formData,
                        success: function (response) {
                            Swal.fire({
                                title: "Successfully Saved!",
                                icon: "success",
                                showConfirmButton: false,
                                timer: 1090,
                                timerProgressBar: true
                            });

                            setTimeout(() => {
                                window.location.href = "travelorder.php";
                            }, 1090);
                        },
                        error: function () {
                            Swal.fire({
                                title: "Error!",
                                text: "There was an issue saving the travel order.",
                                icon: "error"
                            });
                        }
                    });
                }
            });
        });
    });
</script>


</body>

</html>