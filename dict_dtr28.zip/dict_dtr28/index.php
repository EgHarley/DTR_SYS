<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}

include 'include/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
    <script>
        function updateDateTime() {
        const now = moment();
        document.getElementById('date-time-form').innerHTML = 
            `<span style="color: black;">${now.format('dddd, MMMM D, YYYY')}</span><br>
             <span style="color: #a70000; font-size: 45px">${now.format('hh:mm:ss A')}</span>`;
    }

    setInterval(updateDateTime, 1000);

        window.onload = function() {
            // Show error message if session has error message
            <?php if (isset($_SESSION['error'])): ?>
                document.getElementById('error-message').innerText = "<?php echo $_SESSION['error']; ?>";
                document.getElementById('error-message').style.display = 'block';
                <?php unset($_SESSION['error']); ?> // Clear session error message after displaying
            <?php endif; ?>
        };
    </script>
    <style>
        body {
            background: linear-gradient(to bottom, #ffffff 0%, #ffffff 68%, #10346C 100%);
            background-size: cover;
            background-attachment: fixed;
            zoom: 93%;
        }

        .datetime-box {
            text-align: center;
            font-size: 25.8px;
            font-weight: bold;
            color:rgb(0, 0, 0);
            /* font-family: Digital-7 mono; */
        }

        /* Added shadow to login card */
        .card {
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
            background-color: #D9D9D6 !important;
            border-radius: 10px;
        }

        #error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
            text-align: center;
        }

        .btn-primary {
            background-color: #10346C !important;
            border-color: #10346C !important;
            border: 2px solid #10346C !important;
            border-radius: 10px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-primary:hover {
            background-color: #0d2b58 !important;
            border-color: #0d2b58 !important;
        }

        .btn-apply-to {
            background-color: white !important;
            color: #10346C !important;
            border: 2px solid #10346C !important;
            border-radius: 10px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-apply-to:hover {
            background-color: #10346C !important;
            color: white !important;
        }
        
        input.form-control {
            border: 1px solid black;
            border-radius: 10px;
        }

        /* LOGO */
        .logo-container {
            text-align: center;
            margin-bottom: 15px;
            margin-top: -30px;
        }

        .logo-container img {
            width: 110px; 
            margin: 0 10px; 
        }

        .card-header h3 {
            font-size: 22px; /* Smaller text */
            font-weight: normal;
            font-family: Inter;
        }

        input.form-control:focus {
            background-color: #f0f8ff; /* Light blue background when clicked */
            border-color: #10346C; /* Change border color */
            outline: none; /* Remove default focus outline */
            box-shadow: 0 0 8px rgba(16, 52, 108, 0.5); /* Add a subtle glow */
        }
        /* .system-title {
            text-align: center;
            font-weight: bold;
            font-size: 19px;
            font-family: Inter;
            margin-top: 5px;
            color: #10346C;
        } */
    </style>
</head>
<body>
    <div class="container mt-5">

            <!-- Logo Container -->
            <div class="logo-container">
                <img src="images/DICT.png" alt="DICT Logo">
                <img src="images/bagong_pinas.png" alt="Bagong Pilipinas Logo">
                <!-- <h4 class="system-title">Automated Daily Time Record and <br> Travel Order System</h4> -->
            </div>

        <div class="row justify-content-center">
            <!-- Login Form -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Account Login</h3>
                    </div>
                    <div class="card-body">
                        <!-- Current Date & Time inside Login Form -->
                        <div class="datetime-box">
                            <p id="date-time-form">Loading...</p>
                        </div>

                        <!-- Display error message if available -->
                        <div id="error-message"></div>

                        <form action="login_process.php" method="POST">
                            <div class="mb-1">
                                <label class="form-label">
                                    <i class="fas fa-user"></i> Username
                                </label>
                                <input type="text" name="username" class="form-control" required>
                            </div>

                            <div class="mb-2">
                                <label class="form-label">
                                    <i class="fas fa-lock"></i> Password
                                </label>
                                    <div class="input-group">
            <input type="password" name="password" id="password" class="form-control" style="border-radius: 10px;" required>
            <button class="btn" type="button" id="togglePassword" style="position: absolute; border-color: transparent; border-radius: 10px; margin-right: -10px; right: 10px; display: none;">
                <i class="fas fa-eye"></i>
            </button>
            <script>
                document.getElementById("password").addEventListener("input", function () {
                    document.getElementById("togglePassword").style.display = this.value ? "block" : "none";
                });
            </script>
        </div>
    </div>

    <script>
        document.getElementById("togglePassword").addEventListener("click", function () {
            const passwordField = document.getElementById("password");
            const toggleIcon = this.querySelector("i");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            }
        });
    </script>

                            <!-- Added text for registration -->
                            <p class="text-center mt-3">
                                You don't have an account yet? <a href="register/register.php">Click to Register</a>
                            </p>

                            <button type="submit" class="btn btn-primary w-100 mb-2">Login</button>
                            <button type="button" class="btn btn-apply-to w-100" onclick="window.location.href='applyto/applyto.php'">Apply for TO</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
        
    <script>
        updateDateTime(); // Initialize immediately
    </script>
</body>
</html>
