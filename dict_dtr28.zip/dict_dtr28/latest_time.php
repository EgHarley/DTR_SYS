<?php
// Database connection (adjust credentials as needed)
$conn = new mysqli('localhost', 'username', 'password', 'database_name');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query the latest record
$sql = "SELECT record, time FROM attendance ORDER BY time DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row);
} else {
    echo json_encode(['record' => 'No records', 'time' => '']);
}
$conn->close();
?>