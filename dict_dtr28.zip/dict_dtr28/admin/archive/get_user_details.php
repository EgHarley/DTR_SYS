<?php
include '../../connection.php';

if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request. User ID missing.']);
    exit();
}

$user_id = intval($_GET['user_id']);

$query = "SELECT * FROM tbl_archived_user WHERE arch_id = $user_id";
$result = mysqli_query($conn, $query);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode([
        'status' => 'success',
        'data' => $row
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found.']);
}

exit();
?>
