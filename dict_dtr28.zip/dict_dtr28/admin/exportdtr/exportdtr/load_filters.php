<?php
require '../connection.php'; // Adjust path as needed

header('Content-Type: application/json');

$response = [
    'years' => [],
    'months' => [],
    'designations' => [],
    'divisions' => []
];

// Fetch unique years
$yearQuery = "SELECT DISTINCT YEAR(date_approved) AS year FROM tbl_user ORDER BY year DESC";
$yearResult = $conn->query($yearQuery);
while ($row = $yearResult->fetch_assoc()) {
    $response['years'][] = $row['year'];
}

// Fetch unique months
$monthQuery = "SELECT DISTINCT MONTHNAME(date_approved) AS month FROM tbl_user ORDER BY MONTH(date_approved)";
$monthResult = $conn->query($monthQuery);
while ($row = $monthResult->fetch_assoc()) {
    $response['months'][] = $row['month'];
}

// Fetch unique designations
$designationQuery = "SELECT DISTINCT designation FROM tbl_user ORDER BY designation";
$designationResult = $conn->query($designationQuery);
while ($row = $designationResult->fetch_assoc()) {
    $response['designations'][] = $row['designation'];
}

// Fetch unique divisions
$divisionQuery = "SELECT DISTINCT division FROM tbl_user ORDER BY division";
$divisionResult = $conn->query($divisionQuery);
while ($row = $divisionResult->fetch_assoc()) {
    $response['divisions'][] = $row['division'];
}

echo json_encode($response);
?>
