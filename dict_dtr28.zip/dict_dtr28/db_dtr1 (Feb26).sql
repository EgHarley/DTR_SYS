-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2025 at 01:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_dtr1`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `undertime` int(11) NOT NULL,
  `record_date` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `username`, `time_in`, `time_out`, `undertime`, `record_date`, `created_at`, `updated_at`) VALUES
(1, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'erl', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 81, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 122, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'erl', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 81, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'admin', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2025-02-19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 146, '2025-02-20', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 146, '2025-02-20', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 146, '2025-02-20', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 233, '2025-02-21', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 233, '2025-02-21', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'pao', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2025-02-21', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 'erl', '0000-00-00 00:00:00', '2025-02-25 07:30:22', 150, '2025-02-25', '0000-00-00 00:00:00', '2025-02-25 14:30:22'),
(28, 'erl', '0000-00-00 00:00:00', '2025-02-25 07:30:22', 150, '2025-02-25', '0000-00-00 00:00:00', '2025-02-25 14:30:22'),
(29, 'pao', '2025-02-25 04:13:33', '2025-02-25 04:13:36', 46, '2025-02-25', '2025-02-25 11:13:33', '2025-02-25 11:13:36'),
(30, 'erl', '2025-02-25 07:30:10', '2025-02-25 07:30:22', 150, '2025-02-25', '2025-02-25 14:30:10', '2025-02-25 14:30:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(16) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `pword` varchar(250) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `mname` varchar(250) NOT NULL,
  `ulvl` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `uname`, `pword`, `fname`, `lname`, `mname`, `ulvl`) VALUES
(1, 'admin', 'admin', 'Emil', 'Rosario', 'June', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_archived_user`
--

CREATE TABLE `tbl_archived_user` (
  `arch_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `division` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `remaining_days` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_archived_user`
--

INSERT INTO `tbl_archived_user` (`arch_id`, `username`, `password`, `fname`, `division`, `designation`, `position`, `remaining_days`) VALUES
(1, 'admiS', '1234', 'RyaS', 'AFDS', 'Ilocos NorteS', 'SupportS', '2025-02-26 06:12:40.527066'),
(2, 'pao', '1234', 'Thomas', 'AFD', 'Biday', 'Janitor', '2025-02-26 06:13:03.498886'),
(3, 'erl', '1234', 'Earlpindo', 'TOD', 'Luna', 'Dishwasher', '2025-02-26 06:13:14.078368'),
(4, 'Earl1$', '1234', 'Earl', 'TOD', 'La Union', 'Support', '2025-02-26 06:16:45.136503'),
(5, 'admiN9_', '1234', 'Ryan', 'AFD', 'Ilocos Norte', 'Support', '2025-02-26 06:32:44.876761'),
(6, 'charlie_adams', 'charliepass', 'Charlie Adams', 'Marketing', 'Marketing Executive', 'Senior Marketer', '2025-02-26 06:51:45.001544'),
(7, 'jayem', '1234', 'John Michael Onato', 'AFD', 'La Union', '69', '2025-02-26 07:32:41.127390');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `reg_id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(150) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date_registered` datetime NOT NULL DEFAULT current_timestamp(),
  `ulvl` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`reg_id`, `username`, `password`, `fname`, `division`, `designation`, `position`, `status`, `date_registered`, `ulvl`) VALUES
(29, 'david_clarkss', 'davidsecure', 'David Clark', 'AFD', 'La Union', 'Sales Representative', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(30, 'emma_davis', 'emmapass', 'Emma Davis', 'HR', 'Recruitment Officer', 'HR Specialist', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(31, 'frank_evans', 'franksecure', 'Frank Evans', 'IT', 'System Analyst', 'IT Specialist', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(32, 'grace_foster', 'gracepass', 'Grace Foster', 'Finance', 'Auditor', 'Senior Auditor', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(33, 'henry_green', 'henrysecure', 'Henry Green', 'Operations', 'Logistics Coordinator', 'Operations Supervisor', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(34, 'isabella', 'isabellapass', 'Isabella Harris', 'AFD', 'La Union', 'Corporate Lawyer', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(35, 'jackson_lee', 'jacksonsecure', 'Jackson Lee', 'Customer Support', 'Support Specialist', 'Customer Service Rep', 'Pending', '2025-02-26 14:43:48', 'Employee'),
(36, 'karen_moore', 'karenpass', 'Karen Moore', 'R&D', 'Research Scientist', 'Senior Researcher', 'Pending', '2025-02-26 14:43:48', 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_travel_order`
--

CREATE TABLE `tbl_travel_order` (
  `id` int(11) NOT NULL,
  `to_no` varchar(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `dates` varchar(50) NOT NULL,
  `purpose` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_travel_order`
--

INSERT INTO `tbl_travel_order` (`id`, `to_no`, `username`, `dates`, `purpose`, `created_at`, `status`) VALUES
(35, 'R1-32-5SE', 'pao', 'ass', 'ass', '2025-02-21 03:13:34', 'Pending'),
(36, 'R1-27-6666', 'pao', 'vv', 'jhvss', '2025-02-21 14:25:59', 'Pending'),
(37, 'QW-WQ-WQQQ', 'erl', 'qwwwqqqq', 'qwqwqqq', '2025-02-27 03:43:32', 'Approved'),
(38, 'EW-Q2-E12E', 'pao', 'asd', 'dasd', '2025-02-27 08:42:42', 'Pending'),
(39, 'SA-DS', 'pao', 'sadas', 'dassa', '2025-02-27 08:44:01', 'Pending'),
(40, 'SD-A', 'pao', 'sad', 'sad', '2025-02-27 08:44:13', 'Pending'),
(41, 'SA-FD-SA', 'pao', 'asfsf', 'asfsf', '2025-02-27 08:50:11', 'Pending'),
(42, 'EQ-21-2WQR', 'pao', 'qesaf', 'asfasf', '2025-02-27 08:51:43', 'Pending'),
(43, 'WE', 'pao', 'qe1', 'sa', '2025-02-27 08:51:57', 'Pending'),
(44, 'DF-QW', 'pao', 'fewsd', 'afsd', '2025-02-27 08:52:32', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `username` varchar(16) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `ulvl` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date_approved` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`username`, `password`, `fname`, `division`, `designation`, `position`, `ulvl`, `status`, `date_approved`) VALUES
('admin', 'admin', 'Rico Batas Del Rosario', 'AFD', 'La Union', 'Administrator', 'Administrator', 'Approved', '2025-02-26 14:44:39'),
('alulu', '1234', 'Uvivuvuwavwuavwuavwve Osas', 'AFD', 'Ilocos Norte', 'I DUnno', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('earl', '1234', 'Eroll James Adamor', 'AFD', 'La Union', 'Marksman', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('Earl1$', '1234', 'Earl', 'TOD', 'La Union', 'Support', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('eg', '1234', 'onido onatoss', 'AFD', 'Pangasinan', 'onata', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('egss', '1234', 'EG G. Scrambled', 'TOD', 'Pangasinan', 'Tank', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('erl', '1234', 'Earlpindo', 'TOD', 'Luna', 'Dishwasher', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('erle', '1234', 'Steve D. Delmonte', 'AFD', 'Ilocos Sur', 'Support', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('erll', '1234', 'Earl Jimson Venzone', 'TOD', 'La Union', 'Tank', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('liam_nelson', 'liamsecure', 'Liam Nelson', 'Engineering', 'Mechanical Engineer', 'Lead Engineer', 'Employee', 'Approved', '2025-02-26 14:49:57'),
('pao', '1234', 'Thomas', 'AFD', 'Biday', 'Janitor', 'Employee', 'Approved', '2025-02-26 14:44:39'),
('thomassss', '1234', 'Tom Renato Onidosass', 'TOD', 'Pangasinan', 'Junglerss', 'Employee', 'Approved', '2025-02-26 14:44:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_archived_user`
--
ALTER TABLE `tbl_archived_user`
  ADD PRIMARY KEY (`arch_id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `tbl_travel_order`
--
ALTER TABLE `tbl_travel_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

TRUNCATE TABLE `attendance_records`;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_archived_user`
--
ALTER TABLE `tbl_archived_user`
  MODIFY `arch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_travel_order`
--
ALTER TABLE `tbl_travel_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
