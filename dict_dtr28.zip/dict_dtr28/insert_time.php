<?php
session_start();
include 'connection.php'; // Ensure this connects properly to your database

// Check if `action` is set in the POST request
if (isset($_POST['action'])) {
    $action = $_POST['action'];
} else {
    echo "Error: Action is not defined.";
    exit;
}

// Handle Time In action
if ($action === 'time_in') {
    $username = $_POST['username'];
    $time_in = date('Y-m-d H:i:s', strtotime($_POST['time_in']));
    $record_date = date('Y-m-d', strtotime($_POST['time_in']));

    $sql = "INSERT INTO attendance_records (username, record_date, time_in) VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE time_in = VALUES(time_in)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $record_date, $time_in);

    if ($stmt->execute()) {
        echo "AM Time In recorded successfully!";
    } else {
        echo "Error recording AM Time In: " . $stmt->error;
    }
    $stmt->close();
}

if ($action === 'time_out') {
    $username = $_POST['username'];
    $time_out = date('Y-m-d H:i:s', strtotime($_POST['time_out']));
    $record_date = date('Y-m-d', strtotime($_POST['record_date']));

    $sql = "UPDATE attendance_records SET time_out = ? WHERE username = ? AND record_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $time_out, $username, $record_date);

    if ($stmt->execute()) {
        echo "AM Time Out recorded successfully!";
    } else {
        echo "Error recording AM Time Out: " . $stmt->error;
    }
    $stmt->close();
}

if ($action === 'time_in_pm') {
    $username = $_POST['username'];
    $time_in_pm = date('Y-m-d H:i:s', strtotime($_POST['time_in_pm']));
    $record_date = date('Y-m-d', strtotime($_POST['time_in_pm']));

    $sql = "UPDATE attendance_records SET time_in_pm = ? WHERE username = ? AND record_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $time_in_pm, $username, $record_date);

    if ($stmt->execute()) {
        echo "PM Time In recorded successfully!";
    } else {
        echo "Error recording PM Time In: " . $stmt->error;
    }
    $stmt->close();
}

if ($action === 'time_out_pm') {
    $username = $_POST['username'];
    $time_out_pm = date('Y-m-d H:i:s', strtotime($_POST['time_out_pm']));
    $record_date = date('Y-m-d', strtotime($_POST['record_date']));
    $undertime = isset($_POST['undertime']) ? $_POST['undertime'] : 0;

    $sql = "UPDATE attendance_records SET time_out_pm = ?, undertime = ? WHERE username = ? AND record_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siss", $time_out_pm, $undertime, $username, $record_date);

    if ($stmt->execute()) {
        echo "PM Time Out recorded successfully!";
    } else {
        echo "Error recording PM Time Out: " . $stmt->error;
    }
    $stmt->close();
}

?>