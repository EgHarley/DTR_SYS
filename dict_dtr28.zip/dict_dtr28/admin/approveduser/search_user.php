<?php
require '../connection.php'; // Ensure database connection

$search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : "";
$sort = isset($_POST['sort']) ? $_POST['sort'] : "username_asc";

$order_by = "username ASC"; // Default sorting

// Set sorting based on dropdown selection
switch ($sort) {
  case "username_desc":
    $order_by = "username DESC";
    break;
  case "name_asc":
    $order_by = "fname ASC";
    break;
  case "name_desc":
    $order_by = "fname DESC";
    break;
  case "position_asc":
    $order_by = "position ASC";
    break;
  case "position_desc":
    $order_by = "position DESC";
    break;
}

// SQL query with search and sorting
$query = "SELECT * FROM tbl_user 
          WHERE status = 'approved' 
          AND (fname LIKE '%$search%' 
          OR username LIKE '%$search%') 
          ORDER BY $order_by";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    
    $full_name = $row['fname'];
    echo "<tr>
            <td style='background-color: #DEDEDE; color: black;'>{$row['username']}</td>
            <td style='background-color: #DEDEDE; color: black;'>{$full_name}</td>
            <td style='background-color: #DEDEDE; color: black;'>{$row['position']}</td>
            <td style='background-color: #DEDEDE; color: black;'>
              <button class='btn btn-primary btn-sm' 
                  style='background-color: #10346C; color: white; border-color: #10346C;' 
                  onclick='viewUser(\"{$row['username']}\")'>View</button>
            </td>
          </tr>";
  }
} else {
  echo "<tr><td colspan='5' class='text-center'>No records found.</td></tr>";
}
?>
