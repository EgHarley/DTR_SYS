<?php
session_start();
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// include 'include/header.php'
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Export DTR</title>
  <link rel="icon" type="image/x-icon" href="../../images/LOGO.ico">
  <link rel="stylesheet" href="../../sidebar/style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <!-- sweet alert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
  body {
    font-family: Arial, sans-serif;
  }

  ul.nav-list {
    padding-left: 0rem;
  }

  .dropdown-links {
    display: none;
    /* Hide the links by default */
    list-style-type: none;
    padding-left: 20px;
  }

  /* Show dropdown on hover */
  .dropdown:hover .dropdown-links {
    display: block;
  }

  .dropdown-links li {
    margin: 5px 0;
  }

  .dropdown-links a {
    text-decoration: none;
    color: white;
  }

  .dropdown-links a:hover {
    color: #007bff;
    /* Change color on hover */
  }

  .icon {
    display: block;
    margin: 75px auto 0;
    width: 200px;
    height: auto;
  }

  #btn {
    height: 90px;
    /* Adjust height */
    /* line-height: 100px;  */
  }

  .user-info-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    margin-top: 10px;
  }

  .user-info {
    display: flex;
    align-items: center;
    color: #000;
  }

  .current-date {
    color: #000;
    font-size: 16px;
  }

  .card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
    margin-top: -55px;
  }

  .time-display {
    font-size: 72px;
    font-weight: bold;
    margin: 5px 0;
    /* font-family: Digital-7 mono; */
  }

  .time-buttons button {
    padding: 15px 30px;
    margin: 10px;
    font-size: 18px;
    border-radius: 8px;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.6);
  }

  .time-buttons button:disabled {
    background-color: #6c757d !important;
    /* Gray color */
    border-color: #6c757d !important;
    cursor: not-allowed;
    opacity: 0.65;
    /* Slight transparency */
  }

  table {
    width: 100%;
    margin-top: 40px;
    border-collapse: collapse;
  }

  table th,
  table td {
    padding: 15px;
    border: 1px solid #dee2e6;
    text-align: center;
  }

  table th {
    background-color: #f1f1f1;
    font-size: 18px;
  }

  table td {
    font-size: 16px;
  }

  /* history button */
  .history-btn {
    background-color: #10346C !important;
    border-color: #10346C !important;
    box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
  }

  .history-btn:hover {
    background-color: #0c2957 !important;
    border-color: #0c2957 !important;
  }

  .custom-confirm-button {
    background-color: #10346C !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }

  .custom-cancel-button {
    background-color: #E60000 !important;
    color: white !important;
    margin-right: 10px !important;
    width: 80px;
  }
</style>

<body>
  <div class="sidebar">
    <div class="logo_details">
      <img src="../../images/dict_logo.png" alt="Logo" class="icon">
      <!-- <div class="logo_name">Try</div> -->
      <i class="bx bx-menu" id="btn"></i>
    </div><br><br>
    <ul class="nav-list">
      <li>
        <a href="exportdtr.php" class="active">
          <i class="fa-solid fa-calendar-check" title="Export DTR"></i>
          <span class="link_name">Export DTR</span>
        </a>
      </li>
      <li>
        <a href="../approvedto/approvedto.php" title="Approved TOs">
          <i class="fa-solid fa-file-circle-check"></i>
          <span class="link_name">Approved TOs</span>
        </a>
      </li>
      <li>
        <a href="../approveduser/approveduser.php" title="Approved Users">
          <i class="fa-solid fa-user-check"></i>
          <span class="link_name">Approved Users</span>
        </a>
      </li>
      <li>
        <a href="../forapprovalto/forapprovalto.php" title="For Approval of TOs">
          <i class="fa-solid fa-file-circle-exclamation"></i>
          <span class="link_name">For Approval of TOs</span>
        </a>
      </li>
      <li>
        <a href="../forapprovaluser/approvaluser.php" title="For Approval of Users">
          <i class="fa-solid fa-user-plus"></i>
          <span class="link_name">For Approval of Users</span>
        </a>
      </li>
      <li>
        <a href="">
          <i class="fa-solid fa-box-archive"></i>
          <span class="link_name">Archive</span>
        </a>
      </li>

      <!-- <li class="dropdown">
      <a href="#" class="dropdown-toggle">
        <i class="bx bx-chat"></i>
        <span class="link_name">Policy Management</span>
      </a>
      <span class="tooltip">Policy Management</span>
      <ul class="dropdown-links">
        <li><a href="memo.php">Circular Memorandum</a></li>
        <li><a href="reso.php">Resolution</a></li>
        <li><a href="pnp.php">PNP Policy</a></li>
        <li><a href="#">Add Policy</a></li>
      </ul>
    </li> -->
    </ul>
  </div>

  <section class="home-section">

    <?php include '../../include/header.php'; ?>

    <div class="user-info-container">
      <div class="user-info">
        <i class="fa-solid fa-circle-user" style="font-size: 18px; color: #10346C; margin-right: 3px;"></i>
        <span>Logged in as
          <?php
          echo htmlspecialchars($_SESSION['ulvl']) . ", " . htmlspecialchars($_SESSION['fullname']);
          ?>
        </span>
        <a href="logout/logout.php" id="logoutLink" style="text-decoration: none; padding-left: 10px;">
          <i class="fa fa-lock" style="font-size: 18px; color: #10346C;"></i>
          <span style="color: black;">Logout</span>
        </a>
      </div>

      <div class="current-date d-flex align-items-center">
        <i class="fa-solid fa-calendar-days me-2" style="font-size: 18px; color: #10346C;"></i>
        <span id="current-date"></span>
      </div>
    </div>

    <br><br>

    <!-- main dash contents -->
    <main class="px-3 py-2" style="background-color: #e6e4e4;">
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
              <i class="fa-solid fa-calendar-check me-2 fs-4"></i>
              <span class="fw-bold fs-4">Export DTR</span>
            </div>
            <!-- <a href="history.php" class="btn btn-primary history-btn">History</a> -->
          </div>

  <!-- Filters Section -->
  <div class="d-flex mb-3">
    <select id="yearDropdown" class="form-select me-2" style="width: 200px;">
      <option value="">Year</option>
    </select>

    <select id="monthDropdown" class="form-select me-2" style="width: 200px;">
      <option value="">Month</option>
    </select>

    <select id="periodDropdown" class="form-select me-2" style="width: 200px;">
      <option value="">Period</option>
      <option value="1st Half">1st Half</option>
      <option value="2nd Half">2nd Half</option>
    </select>

    <select id="designationDropdown" class="form-select me-2" style="width: 200px;">
    <option value="">Designation</option>
    </select>

    <select id="divisionDropdown" class="form-select me-2" style="width: 200px;">
    <option value="">Division</option>
    </select>

    <div>
    <button id="showButton" class="btn btn-primary">Show</button>
    </div>
    <div>
    <button id="exportButton" class="btn btn-primary">Export</button>
    </div>
  </div>

  <!-- User Table -->
  <div class="table-responsive">
    <table class="table table-hover">
      <thead>
        <tr>
          <th>Full Name</th>
          <th>Designation</th>
          <th>Division</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody id="userTable">
        <!-- Data will be inserted here via AJAX -->
      </tbody>
    </table>
  </div>
</section>

<!-- JavaScript for Dynamic Filtering -->
<script>
 $(document).ready(function () {
    // Load dropdown options
    $.ajax({
        url: "load_filters.php",
        method: "GET",
        dataType: "json",
        success: function (data) {
            data.years.forEach(year => {
                $('#yearDropdown').append(`<option value="${year}">${year}</option>`);
            });

            data.months.forEach(month => {
                $('#monthDropdown').append(`<option value="${month}">${month}</option>`);
            });

            data.designations.forEach(designation => {
                $('#designationDropdown').append(`<option value="${designation}">${designation}</option>`);
            });

            data.divisions.forEach(division => {
                $('#divisionDropdown').append(`<option value="${division}">${division}</option>`);
            });
        }
    });

    // Fetch filtered data
    $('#showButton').on('click', function () {
        let year = $('#yearDropdown').val();
        let month = $('#monthDropdown').val();
        let period = $('#periodDropdown').val();
        let designation = $('#designationDropdown').val();
        let division = $('#divisionDropdown').val();

        $.ajax({
            url: "fetch_filtered_data.php",
            method: "GET",
            data: { year, month, period, designation, division },
            success: function (data) {
                $('#userTable').html(data);
            }
        });
    });
});


  function viewDTR(username) {
    window.location.href = "view_dtr.php?username=" + encodeURIComponent(username);
  }
</script>

  <!-- Scripts -->
  <script src="../../sidebar/sidebar.js"></script>


    <!-- view button -->
    <script>
    function viewDTR(username) {
      window.location.href = "view_dtr.php?username=" + encodeURIComponent(username);
    }
  </script>

    <!-- search -->
    <script>
    document.getElementById("searchInput").addEventListener("keyup", function () {
      let searchValue = this.value;

      // AJAX Request
      let xhr = new XMLHttpRequest();
      xhr.open("POST", "search_user.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          document.getElementById("userTable").innerHTML = xhr.responseText;
        }
      };
      xhr.send("search=" + encodeURIComponent(searchValue));
    });
  </script>

  <!-- sort -->
  <script>
    function fetchUsers() {
      let searchValue = document.getElementById("searchInput").value;
      let sortValue = document.getElementById("sortDropdown").value;

      let xhr = new XMLHttpRequest();
      xhr.open("POST", "search_user.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          document.getElementById("userTable").innerHTML = xhr.responseText;
        }
      };

      xhr.send("search=" + encodeURIComponent(searchValue) + "&sort=" + encodeURIComponent(sortValue));
    }

    // Attach event listeners
    document.getElementById("searchInput").addEventListener("keyup", fetchUsers);
    document.getElementById("sortDropdown").addEventListener("change", fetchUsers);
  </script>

  <!-- clock -->
  <script>
    function updateClock() {
      const now = new Date();
      const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
      document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' });
    }

    setInterval(updateClock, 1000);

    // Call it immediately to display the time without delay
    updateClock();
  </script>

  <!-- Logout Script -->
  <script>
    document.getElementById("logoutLink").addEventListener("click", function (event) {
      event.preventDefault(); // Prevent immediate navigation

      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: "custom-confirm-button btn",
          cancelButton: "custom-cancel-button btn"
        },
        buttonsStyling: false
      });

      swalWithBootstrapButtons.fire({
        title: "Are you sure you want <br> to log out?",
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        reverseButtons: false
      }).then((result) => {
        if (result.isConfirmed) {
          swalWithBootstrapButtons.fire({
            title: "Successfully logged out!",
            icon: "success",
            showConfirmButton: false, // Remove "OK" button
            timer: 2000, // Auto-close after 2 seconds
            timerProgressBar: true // Show progress bar
          });

          setTimeout(() => {
            window.location.href = "../logout_admin.php"; // Redirect after 2 seconds
          }, 1090);
        }
      });
    });
  </script>

</body>
</html>