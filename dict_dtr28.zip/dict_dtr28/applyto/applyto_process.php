<?php 
include '../connection.php'; // Ensure this file properly initializes $conn

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $toNo = trim($_POST['toNo']);
    $username = trim($_POST['username']);
    $dates = trim($_POST['dates']);
    $purpose = trim($_POST['purpose']);
    $status = "Pending"; // Set status to "Pending"

    // Validate required fields
    if (empty($toNo) || empty($username) || empty($dates) || empty($purpose)) {
        die("Error: All fields are required.");
    }

    // Prepare SQL query
    $stmt = $conn->prepare("INSERT INTO tbl_travel_order (to_no, username, dates, purpose, status) 
                            VALUES (?, ?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("sssss", $toNo, $username, $dates, $purpose, $status);

    // Execute and check for errors
    if ($stmt->execute()) {
        echo "Travel order saved successfully!";
        header("Location: ../index.php?success=1"); // Redirect on success
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
