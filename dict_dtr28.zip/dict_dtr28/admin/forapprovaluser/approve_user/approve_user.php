<?php
include '../../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Check if user already exists in tbl_user
    $checkQuery = "SELECT * FROM tbl_user WHERE username = '$username'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        echo json_encode(['status' => 'error', 'message' => 'User already exists in the system.']);
        exit;
    }

    // Fetch user details from tbl_registration
    $query = "SELECT * FROM tbl_registration WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $password = mysqli_real_escape_string($conn, $row['password']); // Store the password as is
        $fname = mysqli_real_escape_string($conn, $row['fname']);
        $division = mysqli_real_escape_string($conn, $row['division']);
        $designation = mysqli_real_escape_string($conn, $row['designation']);
        $position = mysqli_real_escape_string($conn, $row['position']);
        $ulvl = 'Employee'; // Default user level
        $status = 'Approved';

        // Insert into tbl_user with date_approved
        $insertQuery = "INSERT INTO tbl_user (username, password, fname, division, designation, position, ulvl, status, date_approved) 
                        VALUES ('$username', '$password', '$fname', '$division', '$designation', '$position', '$ulvl', '$status', NOW())";


        if (mysqli_query($conn, $insertQuery)) {
            // Delete user from tbl_registration after successful insert
            $deleteQuery = "DELETE FROM tbl_registration WHERE username = '$username'";
            if (mysqli_query($conn, $deleteQuery)) {
                echo json_encode(['status' => 'success', 'message' => 'User approved and removed from registration.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'User approved, but deletion from registration failed.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error approving user.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'User not found in registration.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}

mysqli_close($conn);
?>