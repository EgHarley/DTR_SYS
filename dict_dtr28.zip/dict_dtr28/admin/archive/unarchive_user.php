<?php
// session_start();
// include '../../connection.php';

// if (isset($_GET['unarchive_id'])) {
//     $archived_id = intval($_GET['unarchive_id']);

//     // Fetch the archived user
//     $getData = mysqli_query($conn, "SELECT * FROM tbl_archived_user WHERE arch_id = $archived_id");
//     if ($row = mysqli_fetch_assoc($getData)) {
//         $currentDate = date("Y-m-d H:i:s"); // 

//         $position = $row['position']; // 'position' in archive table
//         $ulvl = $row['position'];     // use same for 'ulvl'

//         // Insert back into tbl_user
//         $insert = mysqli_query($conn, "INSERT INTO tbl_user 
//             (username, password, fname, division, designation, position, ulvl, status, date_approved) 
//             VALUES (
//                 '" . $row['username'] . "', 
//                 '" . $row['password'] . "', 
//                 '" . $row['fname'] . "', 
//                 '" . $row['division'] . "', 
//                 '" . $row['designation'] . "', 
//                 '$position', 
//                 '$ulvl', 
//                 'Approved', 
//                 '$currentDate'
//             )");

//         if ($insert) {
//             // Delete from archive after successful insert
//             mysqli_query($conn, "DELETE FROM tbl_archived_user WHERE arch_id = $archived_id");
//             echo json_encode(['status' => 'success', 'message' => 'User unarchived successfully.']);
//             exit();
//         } else {
//             echo json_encode(['status' => 'error', 'message' => 'Insert failed: ' . mysqli_error($conn)]);
//             exit();
//         }
//     } else {
//         echo json_encode(['status' => 'error', 'message' => 'Archived user not found.']);
//         exit();
//     }
// } else {
//     echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
//     exit();
// }
?>


<?php
session_start();
include '../../connection.php';

if (isset($_GET['unarchive_id'])) {
    $archived_id = intval($_GET['unarchive_id']);

    // Fetch the archived user
    $getData = mysqli_query($conn, "SELECT * FROM tbl_archived_user WHERE arch_id = $archived_id");
    if ($row = mysqli_fetch_assoc($getData)) {
        $currentDate = date("Y-m-d H:i:s");

        $position = $row['position']; 
        $ulvl = $row['ulvl']; // ✅ NOW properly using 'ulvl' from archived table

        // Insert back into tbl_user
        $insert = mysqli_query($conn, "INSERT INTO tbl_user 
            (username, password, fname, division, designation, position, ulvl, status, date_approved) 
            VALUES (
                '" . $row['username'] . "', 
                '" . $row['password'] . "', 
                '" . $row['fname'] . "', 
                '" . $row['division'] . "', 
                '" . $row['designation'] . "', 
                '$position', 
                '$ulvl', 
                'Approved', 
                '$currentDate'
            )");

        if ($insert) {
            // Delete from archive after successful insert
            mysqli_query($conn, "DELETE FROM tbl_archived_user WHERE arch_id = $archived_id");
            echo json_encode(['status' => 'success', 'message' => 'User unarchived successfully.']);
            exit();
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Insert failed: ' . mysqli_error($conn)]);
            exit();
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Archived user not found.']);
        exit();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    exit();
}
?>
