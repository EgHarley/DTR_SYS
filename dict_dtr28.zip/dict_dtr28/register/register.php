<?php
// Include header
include '../include/header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="icon" type="image/x-icon" href="../images/LOGO.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(to bottom, #ffffff 0%, #ffffff 68%, #10346C 100%);
            background-size: cover;
            background-attachment: fixed;
        }

        /* Prevent scrolling and ensure full height */
        html,
        body {
            height: 100%;
            margin: 0;
            overflow: auto;
            /* Allow scrolling if needed */
        }

        .container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            /* Centering the container */
            width: 100%;
            max-width: 1000px;
            /* Set a maximum width for the card */
            margin-top: 20px;
        }

        .card {
            width: 100%;
            max-width: 600px;
            margin-top: 20px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        .username-feedback {
            font-size: 0.9em;
            color: red;
            margin-top: 3px;
        }

        .container .card {
            background-color: #D9D9D6 !important;
            border-radius: 10px;
            padding: 20px;
            margin-top: -20px;
        }

        .row .form-label {
            font-size: 0.8em;
            /* font-family: Inter;   */
            margin-bottom: -2px;
            margin-top: 15px;
        }

        .row .form-control {
            font-size: 0.8em;
            /* font-family: Inter;   */
            border-radius: 10px;
            border-color: rgb(0, 0, 0);
            margin-bottom: -2px;
        }

        .row .btn-primary {
            font-size: 0.9em;
            height: 35px;
            border-radius: 10px;
            border-color: rgb(0, 0, 0);
            background-color: #10346C !important;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        .row .btn-secondary:hover {
            background-color: #10346C !important;
            border-color:rgb(43, 87, 159) !important;
            color: rgb(255, 255, 255);
        }

        .row .btn-secondary {
            font-size: 0.9em;
            height: 35px;
            border-radius: 8px;
            background-color: rgb(255, 255, 255) !important;
            color: #10346C;
            margin-top: 5px;
            box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3);
        }

        .row .form-control:focus {
            background-color: #f0f8ff;
            /* Light blue background when focused */
            border-color: #10346C;
            /* Dark blue border */
            box-shadow: 0 0 8px rgba(16, 52, 108, 0.5);
            /* Subtle glow effect */
            outline: none;
            /* Remove default outline */
        }

        /* Username (*) */
        .required {
            color: red;
        }

        .custom-confirm-btn {
            background-color: #10346C !important;
            color: white !important;
            margin-right: 10px !important;
            width: 80px;
            padding: 8px 16px !important;
            border-radius: 8px !important;
            border-color: #10346C;
        }

        .custom-cancel-btn {
            background-color: #E60000 !important;
            color: white !important;
            margin-right: 10px !important;
            width: 80px;
            padding: 8px 16px !important;
            border-radius: 8px !important;
            border-color: #E60000;
        }

        .custom-swal-title {
            font-size: 28.5px;
            /* Adjust the size as needed */
            /* font-weight: bold; */
        }
        input.form-control:focus {
            background-color: #f0f8ff; /* Light blue background when clicked */
            border-color: #10346C; /* Change border color */
            outline: none; /* Remove default focus outline */
            box-shadow: 0 0 8px rgba(16, 52, 108, 0.5); /* Add a subtle glow */
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <!-- Registration Form -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center" style="background-color: #D9D9D6; color: black ;">
                        <h3>Register Employee Account</h3>
                    </div>
                    <div class="card-body">
                        <!-- Display error message if available -->
                        <?php if (isset($_GET['error'])): ?>
                            <div class="alert alert-danger">
                                <?php echo htmlspecialchars($_GET['error']); ?>
                            </div>
                        <?php endif; ?>
                        <form action="register_process.php" method="POST">
                            <div class="row">
                                <!-- Username column -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control" required>
                                    <div id="username-feedback" class="username-feedback"></div>

                                    <label class="form-label">Password</label>
                                    <div class="input-group">
                                    <input type="password" name="password" id="password" class="form-control" style="border-radius: 10px;" required>
                                    <button class="btn" type="button" id="togglePassword" style=" font-size: 0.8em; position: absolute; border-color: transparent; border-radius: 10px; margin-right: -10px; right: 10px; display: none;">
                                     <i class="fas fa-eye"></i>
                                </button>
                                <script>
                document.getElementById("password").addEventListener("input", function () {
                    document.getElementById("togglePassword").style.display = this.value ? "block" : "none";
                });
            </script>
                                </div>


<script>
     document.getElementById("togglePassword").addEventListener("click", function () {
            const passwordField = document.getElementById("password");
            const toggleIcon = this.querySelector("i");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            }
        });
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                                    

                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="fname" class="form-control" required>

                                    <!-- <label class="form-label">First Name</label>
                                    <input type="text" name="fname" class="form-control" required>

                                    <label class="form-label">Middle Name</label>
                                    <input type="text" name="mname" class="form-control" required> -->
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Division</label>
                                    <select name="division" class="form-control" required>
                                        <option value="" disabled selected>Select Division</option>
                                        <option value="AFD">AFD</option>
                                        <option value="TOD">TOD</option>
                                    </select>

                                    <label class="form-label">Designation</label>
                                    <select name="designation" class="form-control" required>
                                        <option value="" disabled selected>Select Designation</option>
                                        <option value="Ilocos Norte">Ilocos Norte</option>
                                        <option value="Ilocos Sur">Ilocos Sur</option>
                                        <option value="Pangasinan">Pangasinan</option>
                                        <option value="La Union">La Union</option>
                                    </select>

                                    <label class="form-label">Position</label>
                                    <input type="text" name="position" class="form-control" required>
                                </div>

                            </div>
                            <br>
                            <button type="submit" class="btn btn-primary w-100">Register</button>
                            <button type="button" class="btn btn-secondary w-100" id="backToHome">Back to Home</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- <script>
        $(document).ready(function () {
            $('#username').on('input', function () {
                var username = $(this).val();

                // Check if username is empty
                if (username === '') {
                    $('#username-feedback').text('').css('color', '');
                    return;
                }

                // AJAX request to check username availability and format
                $.ajax({
                    url: 'check_username.php', // PHP script to check if username exists
                    type: 'POST',
                    data: { username: username },
                    success: function (response) {
                        if (response === 'taken') {
                            $('#username-feedback').text('Username is already taken.').css('color', 'red');
                        } else if (response === 'invalid') {
                            $('#username-feedback').text('Username must contain uppercase, lowercase, numbers, and special characters.').css('color', 'orange');
                        } else {
                            $('#username-feedback').text('Username is available.').css('color', 'green');
                        }
                    }
                });
            });
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const form = document.querySelector("form");

            form.addEventListener("submit", function (event) {
                event.preventDefault(); // Prevent immediate form submission

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: "custom-confirm-btn",
                        cancelButton: "custom-cancel-btn"
                    },
                    buttonsStyling: false
                });

                swalWithBootstrapButtons.fire({
                    title: "Are you sure you want <br> to register?",
                    icon: "question",
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        swalWithBootstrapButtons.fire({
                            title: "Successfully Registered!",
                            text: "Your account is waiting for approval from the Administrator",
                            icon: "success"
                        }).then(() => {
                            form.submit(); // Submit form after confirmation
                        });
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        swalWithBootstrapButtons.fire({
                            title: "Are you sure you want to cancel? <br> Your draft will not be saved.",
                            icon: "question",
                            showCancelButton: false,
                            confirmButtonText: "OK"
                        }).then(() => {
                            form.reset(); // Clear form inputs when "OK" is clicked
                            location.reload(); // Refresh the page
                        });
                    }
                });
            });
        });
    </script> -->

    <script>
        $(document).ready(function () {
            let usernameAvailable = false; // Track username status

            $('#username').on('input', function () {
                var username = $(this).val();

                // Check if username is empty
                if (username === '') {
                    $('#username-feedback').text('').css('color', '');
                    usernameAvailable = false;
                    return;
                }

                // AJAX request to check username availability
                $.ajax({
                    url: 'check_username.php', // PHP script to check if username exists
                    type: 'POST',
                    data: { username: username },
                    success: function (response) {
                        if (response === 'taken') {
                            $('#username-feedback').text('Username is already taken.').css('color', 'red');
                            usernameAvailable = false;
                        } else {
                            $('#username-feedback').text('Username is available.').css('color', 'green');
                            usernameAvailable = true;
                        }
                    }
                });
            });

            // Handle form submission
            $("form").on("submit", function (event) {
                event.preventDefault(); // Prevent immediate form submission

                if (!usernameAvailable) {
                    Swal.fire({
                        title: "Invalid Username",
                        text: "Please enter a valid username before proceeding.",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                    return;
                }

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: "custom-confirm-btn",
                        cancelButton: "custom-cancel-btn"
                    },
                    buttonsStyling: false
                });

                swalWithBootstrapButtons.fire({
                    title: "Are you sure you want <br> to register?",
                    icon: "question",
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                    reverseButtons: false
                }).then((result) => {
                    if (result.isConfirmed) {
                        swalWithBootstrapButtons.fire({
                            title: "Successfully Registered!",
                            text: "Your account is waiting for approval from the Administrator",
                            icon: "success"
                        }).then(() => {
                            $("form")[0].submit(); // Submit form after confirmation
                        });
                    }
                    // If "No" is clicked, do nothing (form stays the same)
                });
            });
        });
    </script>

    <!-- back to home -->
    <script>
        document.getElementById("backToHome").addEventListener("click", function (event) {
            event.preventDefault();

            // Check if any input fields have values
            let hasInput = false;
            document.querySelectorAll("input, select").forEach((input) => {
                if (input.value.trim() !== "") {
                    hasInput = true;
                }
            });

            // If there is no input, go directly to index.php
            if (!hasInput) {
                window.location.href = "../index.php";
                return;
            }

            // If there is input, show SweetAlert confirmation
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    title: "custom-swal-title",
                    confirmButton: "custom-confirm-btn",
                    cancelButton: "custom-cancel-btn"
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: "Are you sure you want to go back?",
                html: "If you go back now, you will lose any <br> changes you've made.",
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "../index.php";
                }
            });
        });
    </script>

</body>

</html>