<?php
include '../include/connection.php'; // Adjust the path to your connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']); // Store as plain text
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $division = mysqli_real_escape_string($conn, $_POST['division']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);

    // Check if the username already exists
    $checkQuery = "SELECT COUNT(*) FROM tbl_registration WHERE username = '$username'";
    $result = mysqli_query($conn, $checkQuery);
    $row = mysqli_fetch_array($result);

    if ($row[0] > 0) {
        header("Location: register.php?error=Username already taken. Please choose another.");
        exit();
    }

    // Insert into the database (with ulvl set to 'Employee')
    $query = "INSERT INTO tbl_registration (username, password, fname, division, designation, position, status, date_registered, ulvl) 
              VALUES ('$username', '$password', '$fname', '$division', '$designation', '$position', 'Pending', NOW(), 'Employee')";

    if (mysqli_query($conn, $query)) {
        header("Location: ../index.php?success=Registration successful! Please login.");
        exit();
    } else {
        header("Location: register.php?error=An error occurred. Please try again.");
        exit();
    }
}
?>
