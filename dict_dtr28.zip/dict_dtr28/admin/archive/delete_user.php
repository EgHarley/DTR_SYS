<?php
session_start();
include '../../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = intval($_POST['delete_id']);
    $delete = $conn->prepare("DELETE FROM tbl_archived_user WHERE arch_id = ?");
    $delete->bind_param("i", $delete_id);
    if ($delete->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'User deleted permanently.']);
        exit();
    }
}
echo json_encode(['status' => 'error', 'message' => 'Failed to delete user.']);
exit();
?>
